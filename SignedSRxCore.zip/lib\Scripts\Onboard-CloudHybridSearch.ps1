<#
.SYNOPSIS
    When you run this script you onboard your SharePoint Online (SPO) tenant and your SharePoint server cloud SSA to cloud hybrid search.
    This includes setting up server to server authentication between SharePoint Online and SharePoint Server
.PARAMETER PortalUrl
    SharePoint Online portal URL, for example 'https://contoso.sharepoint.com'.
.PARAMETER CloudSsaId
    Name or id (Guid) of the cloud Search service application, created with the CreateCloudSSA script.
.PARAMETER Credential
    Logon credential for tenant admin. Will prompt for credential if not specified.

.NOTES
    TODO
    - Check that SCS URLs are accessible
        need to invoke as service account
    	*.search.msit.us.trafficmanager.net
		*.search.production.us.trafficmanager.net
		*.search.production.emea.trafficmanager.net
		*.search.production.apac.trafficmanager.net
        https://usfrontendexternal.search.production.us.trafficmanager.net/
#>
Param(
    [Parameter(Mandatory=$true, HelpMessage="SharePoint Online portal URL, for example 'https://contoso.sharepoint.com'.")]
    [ValidateNotNullOrEmpty()]
    [string] $PortalUrl,

    [Parameter(Mandatory=$false, HelpMessage="Name or id (Guid) of the cloud Search service application, created with the CreateCloudSSA script.")]
    [ValidateNotNullOrEmpty()]
    [string] $CloudSsaId,
    
    [Parameter(Mandatory=$false, HelpMessage="Logon credential for tenant admin. Will be prompted if not specified.")]
    [PSCredential] $Credential
)

if ($ACS_APPPRINCIPALID -eq $null) {
    New-Variable -Option Constant -Name ACS_APPPRINCIPALID -Value '00000001-0000-0000-c000-000000000000'
    New-Variable -Option Constant -Name ACS_HOST -Value "accounts.accesscontrol.windows.net"
    New-Variable -Option Constant -Name PROVISIONINGAPI_WEBSERVICEURL -Value "https://provisioningapi.microsoftonline.com/provisioningwebservice.svc"
    New-Variable -Option Constant -Name SCS_AUTHORITIES -Value @(
        "*.search.msit.us.trafficmanager.net",
        "*.search.production.us.trafficmanager.net",
        "*.search.production.emea.trafficmanager.net",
        "*.search.production.apac.trafficmanager.net"
    )
}

New-Variable -Option Constant -Name SCS_APPPRINCIPALID -Value '8f0dc9ad-0d19-4fec-a421-6d0279080014'
New-Variable -Option Constant -Name SCS_APPPRINCIPALDISPLAYNAME -Value 'Search Content Service'
New-Variable -Option Constant -Name SP_APPPRINCIPALID -Value '00000003-0000-0ff1-ce00-000000000000'
New-Variable -Option Constant -Name SPO_MANAGEMENT_APPPROXY_NAME -Value 'SPO App Management Proxy'
New-Variable -Option Constant -Name ACS_APPPROXY_NAME -Value 'ACS'
New-Variable -Option Constant -Name ACS_STS_NAME -Value 'ACS-STS'
New-Variable -Option Constant -Name AAD_METADATAEP_FSTRING -Value 'https://{0}/{1}/metadata/json/1'

$SP_VERSION = "15"
$regKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Office Server\15.0\Search" -ErrorAction SilentlyContinue
if ($regKey -eq $null) {
    $regKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Office Server\16.0\Search" -ErrorAction SilentlyContinue
    if ($regKey -eq $null) {
        throw "Unable to detect SharePoint installation."
    }
    $SP_VERSION = "16"
}

Write-Host "Configuring for SharePoint Server version $SP_VERSION."

function Configure-LocalSharePointFarm
{
    Param(
        [Parameter(Mandatory=$true)][string] $Realm
    )

    # Set up to authenticate as AAD realm
    Set-SPAuthenticationRealm -Realm $Realm

    $acsMetadataEndpoint = $AAD_METADATAEP_FSTRING -f $ACS_HOST,$Realm
    $acsMetadataEndpointUri = [System.Uri] $acsMetadataEndpoint
    $acsMetadataEndpointUriSlash = [System.Uri] "$($acsMetadataEndpoint)/"
    Write-Host "ACS metatada endpoint: $acsMetadataEndpoint"

    # ACS Proxy
    $acsProxy = Get-SPServiceApplicationProxy | ? {
        $_.TypeName -eq "Azure Access Control Service Application Proxy" -and
        (($_.MetadataEndpointUri -eq $acsMetadataEndpointUri) -or ($_.MetadataEndpointUri -eq $acsMetadataEndpointUriSlash))
    }
    if ($acsProxy -eq $null) {
        Write-Host "Setting up ACS proxy..." -Foreground Yellow
        $acsProxy = Get-SPServiceApplicationProxy | ? {$_.DisplayName -eq $ACS_APPPROXY_NAME}
        if ($acsProxy -ne $null) {
            throw "There is already a service application proxy registered with name '$($acsProxy.DisplayName)'. Remove manually and retry."
        }
        $acsProxy = New-SPAzureAccessControlServiceApplicationProxy -Name $ACS_APPPROXY_NAME -MetadataServiceEndpointUri $acsMetadataEndpointUri -DefaultProxyGroup
    } elseif ($acsProxy.Count > 1) {
        throw "Found multiple existing ACS proxies for this metadata endpoint."
    } else {
        Write-Host "Found existing ACS proxy '$($acsProxy.DisplayName)'." -Foreground Green
    }

    # The proxy must be in default group and set as default for authentication to work
    if (((Get-SPServiceApplicationProxyGroup -Default).DefaultProxies | select Id).Id -notcontains $acsProxy.Id) {
        throw "ACS proxy '$($acsProxy.DisplayName)' is not set as the default. Configure manually through Service Application Associations admin UI and retry."
    }

    # Register ACS token issuer
    $acsTokenIssuer = Get-SPTrustedSecurityTokenIssuer | ? {
        (($_.MetadataEndPoint -eq $acsMetadataEndpointUri) -or ($_.MetadataEndPoint -eq $acsMetadataEndpointUriSlash))
    }
    if ($acsTokenIssuer -eq $null) {
        Write-Host "Registering ACS as trusted token issuer..." -Foreground Yellow
        $acsTokenIssuer = Get-SPTrustedSecurityTokenIssuer | ? {$_.DisplayName -eq $ACS_STS_NAME}
        if ($acsTokenIssuer -ne $null) {
            throw "There is already a token issuer registered with name '$($acsTokenIssuer.DisplayName)'. Remove manually and retry."
        }
        try {
            $acsTokenIssuer = New-SPTrustedSecurityTokenIssuer -Name $ACS_STS_NAME -IsTrustBroker -MetadataEndPoint $acsMetadataEndpointUri -ErrorAction Stop
        } catch [System.ArgumentException] {
            Write-Warning "$($_)"
        }
    } elseif ($acsTokenIssuer.Count > 1) {
        throw "Found multiple existing token issuers for this metadata endpoint."
    } else {
        if ($acsTokenIssuer.IsSelfIssuer -eq $true) {
            Write-Warning "Existing trusted token issuer '$($acsTokenIssuer.DisplayName)' is configured as SelfIssuer."
        } else {
            Write-Host "Found existing token issuer '$($acsTokenIssuer.DisplayName)'." -Foreground Green
        }
    }

    # SPO proxy
    $spoProxy = Get-SPServiceApplicationProxy | ? {$_.TypeName -eq "SharePoint Online Application Principal Management Service Application Proxy" -and $_.OnlineTenantUri -eq [System.Uri] $PortalUrl}
    if ($spoProxy -eq $null) {
        Write-Host "Setting up SPO Proxy..." -Foreground Yellow
        $spoProxy = Get-SPServiceApplicationProxy | ? {$_.DisplayName -eq $SPO_MANAGEMENT_APPPROXY_NAME}
        if ($spoProxy -ne $null) {
            throw "There is already a service application proxy registered with name '$($spoProxy.DisplayName)'. Remove manually and retry."
        }
        $spoProxy = New-SPOnlineApplicationPrincipalManagementServiceApplicationProxy -Name $SPO_MANAGEMENT_APPPROXY_NAME -OnlineTenantUri $PortalUrl -DefaultProxyGroup
    } elseif ($spoProxy.Count > 1) {
        throw "Found multiple existing SPO proxies for this tenant URI."
    } else {
        Write-Host "Found existing SPO proxy '$($spoProxy.DisplayName)'." -Foreground Green
    }

    # The proxy should be in default group and set to default
    if (((Get-SPServiceApplicationProxyGroup -Default).DefaultProxies | select Id).Id -notcontains $spoProxy.Id) {
        throw "SPO proxy '$($spoProxy.DisplayName)' is not set as the default. Configure manually through Service Application Associations admin UI and retry."
    }

    return (Get-SPSecurityTokenServiceConfig).LocalLoginProvider.SigningCertificate
}

function Upload-SigningCredentialToSharePointPrincipal
{
    Param(
        [Parameter(Mandatory=$true)][System.Security.Cryptography.X509Certificates.X509Certificate2] $Cert
    )

    $exported = $Cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert)
    $certValue = [System.Convert]::ToBase64String($exported)

    $principal = Get-MsolServicePrincipal -AppPrincipalId $SP_APPPRINCIPALID
    $keys = Get-MsolServicePrincipalCredential -ObjectId $principal.ObjectId -ReturnKeyValues $true | ? Value -eq $certValue
    if ($keys -eq $null) {
        New-MsolServicePrincipalCredential -AppPrincipalId $SP_APPPRINCIPALID -Type Asymmetric -Value $certValue -Usage Verify
    } else {
        Write-Host "Signing credential already exists in SharePoint principal."
    }
}

function Add-ScsServicePrincipal
{
    $spns = $SCS_AUTHORITIES | foreach { "$SCS_APPPRINCIPALID/$_" }
    $principal = Get-MsolServicePrincipal -AppPrincipalId $SCS_APPPRINCIPALID -ErrorAction SilentlyContinue

    if ($principal -eq $null) {
        Write-Host "Creating new service principal for $SCS_APPPRINCIPALDISPLAYNAME with the following SPNs:"
        $spns | foreach { Write-Host $_ }
        $scspn = New-MsolServicePrincipal -AppPrincipalId $SCS_APPPRINCIPALID -DisplayName $SCS_APPPRINCIPALDISPLAYNAME -ServicePrincipalNames $spns
    } else {
        $update = $false
        $spns | foreach {
            if ($principal.ServicePrincipalNames -notcontains $_) {
                $principal.ServicePrincipalNames.Add($_)
                Write-Host "Adding new SPN to existing service principal: $_."
                $update = $true
            }
        }
        if ($update -eq $true) {
            Set-MsolServicePrincipal -AppPrincipalId $principal.AppPrincipalId -ServicePrincipalNames $principal.ServicePrincipalNames
        } else {
            Write-Host "Service Principal already registered, containing the correct SPNs."
        }
    }
}

function Prepare-Environment
{
    $MSOIdCRLRegKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSOIdentityCRL" -ErrorAction SilentlyContinue
    if ($MSOIdCRLRegKey -eq $null) {
        Write-Host "Online Services Sign-In Assistant required, install from http://www.microsoft.com/en-us/download/details.aspx?id=39267." -Foreground Red
    } else {
        Write-Host "Found Online Services Sign-In Assistant!" -Foreground Green
    }

    $MSOLPSRegKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSOnlinePowershell" -ErrorAction SilentlyContinue
    if ($MSOLPSRegKey -eq $null) {
        Write-Host "AAD PowerShell required, install from http://go.microsoft.com/fwlink/p/?linkid=236297." -Foreground Red
    } else {
        Write-Host "Found AAD PowerShell!" -Foreground Green
    }

    if ($MSOIdCRLRegKey -eq $null -or $MSOLPSRegKey -eq $null) {
        throw "Manual installation of prerequisites required."
    }

    Write-Host "Configuring Azure AD settings..." -Foreground Yellow

    $regkey = "HKLM:\SOFTWARE\Microsoft\MSOnlinePowerShell\Path"
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSOIdentityCRL" -Name "ServiceEnvironment" -Value "Production"
    Set-ItemProperty -Path $regkey -Name "WebServiceUrl" -Value $PROVISIONINGAPI_WEBSERVICEURL
    Set-ItemProperty -Path $regkey -Name "FederationProviderIdentifier" -Value "microsoftonline.com"

    Write-Host "Restarting MSO IDCRL Service..." -Foreground Yellow

    # Service takes time to get provisioned, retry restart.
    for ($i = 1; $i -le 10; $i++) {
        try {
            Stop-Service -Name msoidsvc -Force -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
            $svc = Get-Service msoidsvc
            $svc.WaitForStatus("Stopped")
            Start-Service -Name msoidsvc
        } catch {
            Write-Host "Failed to start msoidsvc service, retrying..."
            Start-Sleep -seconds 2
            continue
        }
        Write-Host "Service Restarted!" -Foreground Green
        break
    }
}

function Get-CloudSsa
{
    $ssa = $null

    if (-not $CloudSsaId) {
        $ssa = Get-SPEnterpriseSearchServiceApplication
        if ($ssa.Count -ne 1) {
            throw "Multiple SSAs found, specify which cloud SSA to on-board."
        }
    } else {
        $ssa = Get-SPEnterpriseSearchServiceApplication -Identity $CloudSsaId
    }

    if ($ssa -eq $null) {
        throw "Cloud SSA not found."
    }

    # Make sure SSA is created with CreateCloudSSA.ps1
    if ($ssa.CloudIndex -ne $true) {
        throw "The provided SSA is not set up for cloud hybrid search, please create a cloud SSA before proceeding with onboarding."
    }

    Write-Host "Using SSA with id $($ssa.Id)."
    $ssa.SetProperty("IsHybrid", 1)
    $ssa.Update()

    return $ssa
}

$code = @"
using System;
using System.Net;
using System.Security;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.IdentityModel;
using Microsoft.SharePoint.IdentityModel.OAuth2;

static public class ClientContextHelper
{
    public static ClientContext GetAppClientContext(string siteUrl)
    {
        SPServiceContext serviceContext = SPServiceContext.GetContext(SPServiceApplicationProxyGroup.Default, SPSiteSubscriptionIdentifier.Default);
        using (SPServiceContextScope serviceContextScope = new SPServiceContextScope(serviceContext))
        {
            ClientContext clientContext = new ClientContext(siteUrl);
            ICredentials credentials = null;
            clientContext.ExecutingWebRequest += (sndr, request) =>
            {
                    request.WebRequestExecutor.RequestHeaders.Add(HttpRequestHeader.Authorization, "Bearer");
                    request.WebRequestExecutor.WebRequest.PreAuthenticate = true;
            };

            // Run elevated to get app credentials
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
               credentials = SPOAuth2BearerCredentials.Create();
            });

            clientContext.Credentials = credentials;

            return clientContext;
        }
    }
}
"@

$assemblies = @(
"System.Core.dll",
"System.Web.dll",
"Microsoft.SharePoint, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c",
"Microsoft.SharePoint.Client, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c",
"Microsoft.SharePoint.Client.Runtime, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c"
)

Add-Type -AssemblyName ("Microsoft.SharePoint.Client, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")
Add-Type -AssemblyName ("Microsoft.SharePoint.Client.Search, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")
Add-Type -AssemblyName ("Microsoft.SharePoint.Client.Runtime, Version=$SP_VERSION.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")
Add-Type -TypeDefinition $code -ReferencedAssemblies $assemblies

Add-PSSnapin Microsoft.SharePoint.PowerShell

try
{
    Write-Host "Accessing Cloud SSA..." -Foreground Yellow
    $ssa = Get-CloudSsa

    Write-Host "Preparing environment..." -Foreground Yellow
    Prepare-Environment

    Import-Module MSOnline
    Import-Module MSOnlineExtended -force

    Write-Host "Connecting to O365..." -Foreground Yellow
    if ($Credential -eq $null) {
        $Credential = Get-Credential -Message "Tenant Admin credential"
    }
    Connect-MsolService -Credential $Credential -ErrorAction Stop
    $tenantInfo = Get-MsolCompanyInformation
    $AADRealm = $tenantInfo.ObjectId.Guid

    Write-Host "AAD tenant realm is $AADRealm."

    Write-Host "Configuring on-prem SharePoint farm..." -Foreground Yellow
    $signingCert = Configure-LocalSharePointFarm -Realm $AADRealm
    
    Write-Host "Adding local signing credential to SharePoint principal..." -Foreground Yellow
    Upload-SigningCredentialToSharePointPrincipal -Cert $signingCert

    Write-Host "Configuring service principal for the cloud search service..." -Foreground Yellow
    Add-ScsServicePrincipal

    Write-Host "Connecting to content farm in SPO..." -foreground Yellow
    $cctx = [ClientContextHelper]::GetAppClientContext($PortalUrl)
    $pushTenantManager = new-object Microsoft.SharePoint.Client.Search.ContentPush.PushTenantManager $cctx

    # Retry up to 4 minutes, mitigate 401 Unauthorized from CSOM
    Write-Host "Preparing tenant for cloud hybrid search (this can take a couple of minutes)..." -foreground Yellow
    for ($i = 1; $i -le 12; $i++) {
        try {
            $pushTenantManager.PreparePushTenant()
            $cctx.ExecuteQuery()
            Write-Host "PreparePushTenant was successfully invoked!" -Foreground Green
            break
        } catch {
            if ($i -ge 12) {
                throw "Failed to call PreparePushTenant, error was $($_.Exception.Message)"
            }
            Start-Sleep -seconds 20
        }
    }

    Write-Host "Getting service info..." -foreground Yellow
    $info = $pushTenantManager.GetPushServiceInfo()
    $info.Retrieve("EndpointAddress")
    $info.Retrieve("TenantId")
    $info.Retrieve("AuthenticationRealm")
    $info.Retrieve("ValidContentEncryptionCertificates")
    $cctx.ExecuteQuery()

    Write-Host "Registered cloud hybrid search configuration:"
    $info | select TenantId,AuthenticationRealm,EndpointAddress | format-list

    if ([string]::IsNullOrEmpty($info.EndpointAddress)) {
        throw "No indexing service endpoint found!"
    }

    if ($info.ValidContentEncryptionCertificates -eq $null) {
        Write-Warning "No valid encryption certificate found."
    }

    if ($AADRealm -ne $info.AuthenticationRealm) {
        throw "Unexpected mismatch between realm ids read from Get-MsolCompanyInformation ($AADRealm) and GetPushServiceInfo ($($info.AuthenticationRealm))."
    }

    Write-Host "Configuring Cloud SSA..." -foreground Yellow
    $ssa.SetProperty("CertServerURL", $PortalUrl)
    $ssa.SetProperty("HybridTenantID", $info.TenantId)
    $ssa.SetProperty("AuthRealm", $info.AuthenticationRealm)
    $ssa.Update()

    Write-Host "Restarting SharePoint Timer Service..." -foreground Yellow
    Stop-Service SPTimerV4
    Write-Host "Restarting SharePoint Server Search..." -foreground Yellow
    if ($SP_VERSION -eq "15") {
        Restart-Service OSearch15
    } else {
        Restart-Service OSearch16
    }
    Start-Service SPTimerV4

    Write-Host "All done!" -foreground Green
}
catch
{
    Write-Error -ErrorRecord $_
    Write-Host "It is safe to re-run onboarding if you believe this error is transient." -Foreground Yellow
    return
}

# SIG # Begin signature block
# MIIkpwYJKoZIhvcNAQcCoIIkmDCCJJQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAQUlMbu/E/C+ZX
# e+HCh8TNhhw7u51NvArv33Ob8KpI76CCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWfDCCFngCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCCAWkwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIABgkJhK
# ZRoN7ReOgjB+XMlRrbI4j4mt+5L/unUI7nfpMIH8BgorBgEEAYI3AgEMMYHtMIHq
# oFaAVABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBs
# AHQAaAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKGBj4CBjGh0
# dHBzOi8vYmxvZ3MubXNkbi5taWNyb3NvZnQuY29tL3NoYXJlcG9pbnRfc3RyYXRl
# Z2VyeS8yMDE2LzAyLzAxL2Fubm91bmNpbmctdGhlLXNlYXJjaC1oZWFsdGgtcmVw
# b3J0cy1zcngtZm9yLXNoYXJlcG9pbnQtc2VhcmNoLWRpYWdub3N0aWNzMA0GCSqG
# SIb3DQEBAQUABIIBAKgtd6xb9Z0rYcm6mNwUhKvhew/6G/IrysCHEAABUHvcFdJK
# lITESIxYUCIiSqTL4C5wVtr2+P6SKUWnSo3MoZPSDEUl4Fy7eFWBc1/QSzp9waTa
# jY1FYGbp61n2pI1nYyZ6/Dtbt3bVkPrC4/Lqmwn1OmY8/DyR7S/tDcbvTWZMBj+K
# EJ/EXSDLEucKMdOicnuh7PeqQPG0dZPnnz/AN/sfZ93M+9FwiTAlwmDRL+Pk02L/
# 3GKuoPgY2u4Cfj48D7JXE1iJfP25ubxCW1/xqnwCcggTM7Ukqp1ALMFppPmHal13
# YcOc9M2D4zEoBP+0rGsZJwdZMt4MLiEgIF567XOhghNKMIITRgYKKwYBBAGCNwMD
# ATGCEzYwghMyBgkqhkiG9w0BBwKgghMjMIITHwIBAzEPMA0GCWCGSAFlAwQCAQUA
# MIIBPQYLKoZIhvcNAQkQAQSgggEsBIIBKDCCASQCAQEGCisGAQQBhFkKAwEwMTAN
# BglghkgBZQMEAgEFAAQgFVHh1EI7MwWmWxfCutzj8u6m7fE648xQ5vZ1i9mg5o8C
# BltohAX4oBgTMjAxODA4MTcyMjA4MDAuNDE2WjAHAgEBgAIB9KCBuaSBtjCBszEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9Q
# UjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNOOkMwRjQtMzA4Ni1ERUY4MSUwIwYD
# VQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIOzTCCBNowggPCoAMC
# AQICEzMAAACj7x8iIIFj3KUAAAAAAKMwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTYwOTA3MTc1NjQ5WhcNMTgwOTA3MTc1
# NjQ5WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsG
# A1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNOOkMwRjQtMzA4Ni1E
# RUY4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqdEel8cTafg4OxUX5kgO+V+CrFSd
# MBqtEF3Q8gX3P2iGN1rQAFPmnG0caPIpx9b/MZhSTRG69cFkhjo5CSdWSV6foSEZ
# KRvMWhbj830BVRcs6eGslvvHma8ocAB1IvoucpRUX7rRxawy1OXWHnnwgaMKvmO+
# eGln4o+F0cm+yH+Qi+S4fpiub74qZAgaSLc5Ichq9CRLYBDUcoByCDjpbvk7U+1Z
# 2yTUTWHIW9NpYwAyvcyxUT3rQLh/uL67ch3BOGzeCY5uLZk6bEUI3rNPW21tgJHZ
# I5tImUwe5RF/sxeedpG94iYWHxEAHDrfmegs/+x1LFgpcKcXLSjuj7SjXwIDAQAB
# o4IBGzCCARcwHQYDVR0OBBYEFPqFumZm6EaZ2nCfuiElQNvg6LFwMB8GA1UdIwQY
# MBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6
# Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBD
# QV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# DQYJKoZIhvcNAQELBQADggEBAB3RRbpbtL+K5oaNRc41iCYSRrAzg2phMcgWc/jm
# JHpqwcAVNzyNxykNSMt0l6Wyh+EGeNVDjFM68OJRDni20/wcjSXlUxoV2T56vMe7
# wU5mWFEYD2UlYSGhvuaRw2CO+Qm0PojCpnKBOxzyEBzVBa6IXTRVUqhDhozwDVS+
# S+RL7heVtpu8AmsWzbItbPWr3zXhBoO0WUHnHgHzaE332N4kLEZLQsCNF3NEUCuN
# 3nbNf3Rd3+ZkzDK4nsDPZVIRCAZ6l7aDZaNi2MODujmOR7hTqsNmGhy9SU703NQH
# rNK40WT54HfJ7HaAxKsXK+sjg7WWifHYS5aS3W+pwjvW85wwggZxMIIEWaADAgEC
# AgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0
# aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEy
# MTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCC
# hfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRU
# QwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FU
# sc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBX
# day9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4
# HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCC
# AeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2ha
# hW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNV
# HRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYG
# A1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3Js
# L3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcB
# AQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kv
# Y2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUw
# gZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0
# HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0
# AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1
# Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRg
# Eop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X
# 9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbl
# jjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQ
# eKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ou
# OVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+9
# 8eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUB
# HoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ay
# p0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXj
# ad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb
# 01+P3nSISRKhggN2MIICXgIBATCB46GBuaSBtjCBszELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNp
# cGhlciBEU0UgRVNOOkMwRjQtMzA4Ni1ERUY4MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBTZXJ2aWNloiUKAQEwCQYFKw4DAhoFAAMVADXko/tOP/8mDXH1
# bV4Se5GWOKaNoIHCMIG/pIG8MIG5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMScwJQYDVQQLEx5uQ2lwaGVyIE5UUyBF
# U046NTdGNi1DMUUwLTU1NEMxKzApBgNVBAMTIk1pY3Jvc29mdCBUaW1lIFNvdXJj
# ZSBNYXN0ZXIgQ2xvY2swDQYJKoZIhvcNAQEFBQACBQDfITF5MCIYDzIwMTgwODE3
# MTkzNTIxWhgPMjAxODA4MTgxOTM1MjFaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIF
# AN8hMXkCAQAwBwIBAAICBIkwBwIBAAICGoEwCgIFAN8igvkCAQAwNgYKKwYBBAGE
# WQoEAjEoMCYwDAYKKwYBBAGEWQoDAaAKMAgCAQACAxbjYKEKMAgCAQACAwehIDAN
# BgkqhkiG9w0BAQUFAAOCAQEAdvmLoHQ0uzEMAO+i0TRa2O9K7SStkvPv7FubtAZE
# vWhvG0U07aW0UWZeEtf3M2GXo5RHJKI4wZmvITe/dOF/Trr0Ph7zBjb8xbZhKtHD
# te5xY837WxhRy0iXnNU0hZw+nrn6XhLEqdjkhLWF/TZcockE9hu+kT7AdthMRZJl
# PMHc1wN2lS07abJea26Peo6GU3ysq3a9c7uyjY8irHCzEZnWstAkCzrpNhwDiVYy
# yPHH/aMAJKucr7eTPLwj0u/ce3dRdvVgK4ZYmUYg86JzAeSbyYUD7HeC+Z8HIKBG
# p8oCxFP17rbAYbXDDCCeAoG6QrRFexsRi6jtqZvH52dXCzGCAvUwggLxAgEBMIGT
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAAo+8fIiCBY9ylAAAA
# AACjMA0GCWCGSAFlAwQCAQUAoIIBMjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwLwYJKoZIhvcNAQkEMSIEIC0P1HFS3z+Tc8GTikA2251ULE1WVciIKeMnKW85
# p0pBMIHiBgsqhkiG9w0BCRACDDGB0jCBzzCBzDCBsQQUNeSj+04//yYNcfVtXhJ7
# kZY4po0wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AKPvHyIggWPcpQAAAAAAozAWBBSqXI61Jm42Gkb4intbw7U8kR8yrjANBgkqhkiG
# 9w0BAQsFAASCAQCYzJHnNS6wHEbLAh8pwSEVYoAA+UW/i3XAd8G5iBgGW7JAq6rm
# EqANXJUth4UrbpEMUeOu8GtYW+q7et04i+VjD0pYwY8+XkdSh1HQzyTMumAMx1Au
# vZXD+2FSiEi7AdU0ms+oXGyJA43rhRqTH0OGdL163NSL6sn5XlrSK/1Va7dK9qbL
# XSl3JgCEmnd/6RDqr54Nica5KqsfPGn0YxaWUEpr4x39S59y3jwzCp8NkziaN5b1
# TzKQ2ask4MReqE1gJG/zWESVmCwRE3H4lhLXi16Hw+suOew2P69nv+GiqkPyl4H7
# fXqj5TWlt95uRIiP1aRHD1lvdC8U7IGhrsli
# SIG # End signature block
