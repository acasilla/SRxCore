#=============================================
# Project		: Search Health Reports (SRx)
#---------------------------------------------
# File Name 	: Enable-SRxRemoteUtilities.psm1
# Author		: Eric Dixon, Brian Pendergrass
# Requires: 
#	PowerShell Version 3.0, Search Health Reports (SRx), Microsoft.SharePoint.PowerShell
#
#==========================================================================================
# This Sample Code is provided for the purpose of illustration only and is not intended to 
# be used in a production environment.  
#
#	THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY
#	OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
#	WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
#
# We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to 
# reproduce and distribute the object code form of the Sample Code, provided that You agree:
#	(i) to not use Our name, logo, or trademarks to market Your software product in 
#		which the Sample Code is embedded; 
#	(ii) to include a valid copyright notice on Your software product in which the 
#		 Sample Code is embedded; 
#	and 
#	(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against
#		  any claims or lawsuits, including attorneys' fees, that arise or result from 
#		  the use or distribution of the Sample Code.
#
#==========================================================================================

function Enable-SRxRemoteTool 
{
<#
.SYNOPSIS

.DESCRIPTION

.INPUTS
	
.NOTES

#>
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true,ValueFromPipeline=$true)]
    $TargetServer,
    [parameter(Mandatory=$true)]
    $ToolName,
    $ToolExe,
    [Object[]]$ToolSupportFiles=@()
)

BEGIN {
    if(-not $global:SRxEnv.RemoteUtilities) {
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities", $(New-Object PSObject))
    }

    $global:OldDriveLetter = $null
    if(AddRemoteTool -ToolName $ToolName) {
        $TargetDrive = GetToolDriveLetter -ToolName $ToolName
	    $status = $true
    } else {
		$status = $false
		return $status
	}

    # add tool to handle map
    if(-not $global:SRxEnv.RemoteUtilities.$ToolName) {
        $o = New-Object PSObject -Property @{
            Initialized=$false;
            Exe=$ToolExe;
            SupportFiles=$ToolSupportFiles;
            Drive=$TargetDrive;
            Servers=@();
        }
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities.$ToolName", $o)
    }

    $serversToAdd = New-Object System.Collections.ArrayList
}

PROCESS {
	if($status -eq $false) {
		return
	}
    # todo: create function member on object
    Write-SRx INFO ("Enabling Remote Utility $ToolName on $($TargetServer.Name)...") -ForegroundColor Cyan 

    $serversToAdd.Add($TargetServer.name) | Out-Null

    try {
        # create folders on target server
        $ScriptBlock = { 
            param([string]$newToolPath)
            New-Item -Path (Join-Path $newToolPath "bin") -type directory -Force | Out-Null
            New-Item -Path (Join-Path $newToolPath "var") -type directory -Force | Out-Null
        }

        $toolPath = GetToolPath -ToolName $ToolName
        Write-SRx INFO ("Copying $ToolName executables to '$toolPath' on $($TargetServer.Name)...") -ForegroundColor Cyan 
        if($env:COMPUTERNAME -eq $TargetServer.Name){
            Invoke-Command -ScriptBlock $ScriptBlock -ArgumentList(,$toolPath)
        } else {
            try{
                Invoke-Command -ComputerName $TargetServer.Name -ScriptBlock $ScriptBlock -ArgumentList(,$toolPath) -ErrorAction Stop
            }catch{
                # connect to the computer from client using kerberos as the current user:
                Invoke-Command -ComputerName $TargetServer.Name -ScriptBlock $ScriptBlock -ArgumentList(,$toolPath) -Authentication NegotiateWithImplicitCredential �
            }
        }

        $toolPath = (GetToolPath -ToolName $ToolName).Replace(":","$")
        $toolPathBin = (Join-Path $toolPath "bin") 
        $destPath = Join-Path "\\$($TargetServer.Name)" $toolPathBin

        # copy files to target server
        Copy-Item (Join-Path $global:SRxEnv.Paths.Tools  $global:SRxEnv.RemoteUtilities.$ToolName.Exe) $destPath -Force -Recurse
        foreach($supportFile in $global:SRxEnv.RemoteUtilities.$ToolName.SupportFiles){
            Copy-Item (Join-Path $global:SRxEnv.Paths.Tools $supportFile) $destPath -Force -Recurse
        }
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities.$ToolName.Initialized", $true)
    } catch {
        Write-SRx ERROR "Failed to create folders and copy files for $ToolName on $($TargetServer.Name)"
        Write-SRx DEBUG "Caught Exception"
        Write-SRx DEBUG "$_"
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities.$ToolName.Initialized", $false)
        $status = $false
    }
}

END {
	if($status) {
        Write-SRx INFO ("Completed enabling $ToolName.") -ForegroundColor Cyan 

        $servers = $global:SRxEnv.RemoteUtilities.$ToolName.Servers
        $newServers = New-Object System.Collections.ArrayList

        foreach($s in $serversToAdd){
            if(-not ($servers -contains $s)) {
                $newServers.Add($s) | Out-Null
            }
        }
        $newServers.AddRange($servers) | Out-Null
        $global:SRxEnv.PersistCustomProperty("RemoteUtilities.$ToolName.Servers", $newServers)
	}

    return $status
}
}



function AddRemoteTool 
{
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true)]
    $ToolName
)

	if($global:SRxEnv.RemoteUtilities.$ToolName.Initialized)
	{
        Write-SRx VERBOSE "$ToolName is initialized."
	}
    else
    {
		$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Copy $ToolName to servers."
		$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Do not copy $ToolName."
		$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)

        Write-Host "The SRx Dashboard can run utilites on remote servers." -BackgroundColor DarkCyan -ForegroundColor White
        Write-Host "Enabling $ToolName implies you accept the EULA for this tool." -BackgroundColor DarkCyan -ForegroundColor White
		$title = "" 
		$message = "Do you want to enable $ToolName for SRx Dashboard?"
		$result = $host.ui.PromptForChoice($title, $message, $options, 1)
		switch ($result) 
		{
			0 { Write-Host "Yes";}
			1 { Write-Host "No"; return $false }
		}

		$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Copy $ToolName to servers."
		$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Do not copy $ToolName."
		$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)

        Write-Host "The $ToolName utility needs to be copied to each server in the search farm." -BackgroundColor DarkCyan -ForegroundColor White
		$title = "" 
		$message = "Do you want to copy the $ToolName utility to each server in the farm?"
		$result = $host.ui.PromptForChoice($title, $message, $options, 1)
		switch ($result) 
		{
			0 { Write-Host "Yes";}
			1 { Write-Host "No"; return $false }
		}

    }

    return $true
}



function GetToolDriveLetter
{
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true)]
    $ToolName
)
    $done = $false
    while(-not $done)
    {
	    Write-Host "Please specify a drive letter that exists on all search servers in the farm" -BackgroundColor DarkCyan -ForegroundColor White
	    Write-Host "where SRx will do all remote utilite file operations for $ToolName." -BackgroundColor DarkCyan -ForegroundColor White
	    while(-not ($driveLetter -match '^[a-zA-Z][:(:\\)]*$'))
	    {
		    Write-Host "Specify an existing drive." -BackgroundColor DarkCyan -ForegroundColor White
		    $driveLetter = Read-Host ">> Drive letter"
	    }
        $driveLetter = ($driveLetter.trim().ToUpper())[0]

	    $yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Accept"
	    $no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Re-enter"
	    $options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
	    $title = "" 
	    $message = "You have entered '$driveLetter'. Is this correct?"
	    $result = $host.ui.PromptForChoice($title, $message, $options, 0)
	    switch ($result) 
	    {
		    0 { Write-Host "Yes"; return $driveLetter}
		    1 { Write-Host "No"; $driveLetter = "";$done = $false }
	    }
    }
}


function GetToolPath
{
    param([string]$ToolName)
    return "$($global:SRxEnv.RemoteUtilities.$ToolName.Drive):\SRx\RemoteUtilities\$ToolName"
}

function IsEnabledRemoteTool {
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true)]
    $ToolName,
    [parameter(Mandatory=$true)]
    $TargetServer
)
    if($global:SRxEnv.RemoteUtilities.$ToolName.Initialized) {
        $servers = $global:SRxEnv.RemoteUtilities.$ToolName.Servers
        # check for .exe, .dll files and bin, var dirs
        $utilitiesFolder = Join-Path $("\\" + $TargetServer.Name) (GetToolPath -ToolName $ToolName)
        $utilitiesFolder = $utilitiesFolder.Replace(':','$')
        $binFolder = Join-Path $utilitiesFolder "bin"
        $varFolder = Join-Path $utilitiesFolder "var"

        $enable = $false
        if(-not ($servers -contains $TargetServer.Name)) {
            Write-SRx Verbose ("[IsEnabledRemoteTool] Server Not Initialized " + $TargetServer.Name) -ForegroundColor Magenta
            $enable = $true
        } elseif(-not (Test-Path (Join-Path $binFolder ($global:SRxEnv.RemoteUtilities.$ToolName.Exe)))) {
            Write-SRx Verbose ("[IsEnabledRemoteTool] " + $global:SRxEnv.RemoteUtilities.$ToolName.Exe + " not found on " + $TargetServer.Name) -ForegroundColor Magenta
            $enable = $true    
        } elseif(-not (Test-Path $varFolder)) {
            Write-SRx Verbose ("[IsEnabledRemoteTool] var folder not found on " + $TargetServer.Name) -ForegroundColor Magenta
            $enable = $true    
        } else {
            $supportFiles = $global:SRxEnv.RemoteUtilities.$ToolName.SupportFiles
            foreach($f in $supportFiles){
                if(-not (Test-Path (Join-Path $binFolder $f))) {
                    Write-SRx Verbose ("[IsEnabledRemoteTool] Support file " + $f + " not found on " + $TargetServer.Name) -ForegroundColor Magenta
                    $enable = $true
                    break
                }
            }
        }

        if($enable){
			Write-SRx Verbose "[IsEnabledRemoteTool] Enabling $ToolName on $($TargetServer.Name)..."-ForegroundColor Magenta
            $TargetServer | Enable-SRxRemoteTool -ToolName $ToolName
        }

        return $true
    }

    return $false
}

function Invoke-SRxRemoteTool 
{
<#
.SYNOPSIS

.DESCRIPTION

.INPUTS
	
.NOTES

#>
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true,ValueFromPipeline=$true,Position=0)]
    $TargetServer,
    [parameter(Mandatory=$true)]
    $ToolName,
    [parameter(Mandatory=$true)]
    [Scriptblock]$CmdBlock,
    [parameter(Mandatory=$true)]
	[Hashtable]$InputParams=@{},
    [parameter(Mandatory=$false)]
	[Object[]]$OutputParams
)
    BEGIN {
        if(-not $SRxEnv.RemoteUtilities.$ToolName){
            throw [System.NullReferenceException] "RemoteUtilities configuration for '$ToolName' not found in `$SRxEnv"
        }

        # to be tricky like Brian
        $HasDebugFlag = ($PSCmdlet.MyInvocation.BoundParameters["Debug"].IsPresent -or $global:SRxEnv.Log.Level -eq "Debug")

        $startTime = Get-Date

        # job list
        $jobList = New-Object System.Collections.ArrayList

        # if utf 8 is enabled, it will put a BOM on the script block input for Start-Job and break it
        # this is not a problem with the ISE, check our host name
	    if ($Host.Name -eq "ConsoleHost") {
            if([system.console]::InputEncoding -is [Text.UTF8Encoding]){
		        [system.console]::InputEncoding= New-Object Text.UTF8Encoding $false
            }
        }
        $jobGUID = [guid]::NewGuid()
        $destPath = New-Item -Path (Join-Path $global:SRxEnv.Paths.Tmp $jobGUID) -type directory -Force
        Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] Invoking command with JobId: $($jobGUID)" -ForegroundColor Cyan

        $ToolPath = GetToolPath -ToolName $ToolName
    }
    PROCESS{
        if (-not $TargetServer.canPing()) {
            Write-SRx ERROR "[Invoke-SRxRemoteTool][$ToolName] Unable to ping $($TargetServer.Name)"
        } elseif (IsEnabledRemoteTool -Tool $ToolName -TargetServer $TargetServer) {
            $jobBlock = {
                param([string]$ToolName,[string]$ToolPath,[string]$TargetServerName,[string]$ToolNameExe,[string]$jobGUID,[string]$destPath,[string]$cmdBlock,[Hashtable]$inParams,[Object[]]$outParams,[bool]$HasDebugFlag)

                $logfile = Join-Path $destPath "job-$TargetServerName-debug.log"
			    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Entered Job block." | Add-Content -Path $logfile }

                $cmdBlock2 = {
                    param([string]$varpath,[string]$guid,[bool]$debug)
                    $zipfile = Join-Path $varpath "$($env:COMPUTERNAME)-$guid.zip"
                    $outpath = Join-Path $varpath $guid
                    if($debug) {
                        $logfile = Join-Path $varPath "$guid.log"
        			    "Creating zip file $zipfile from $outpath" | Add-Content -Path $logfile
                    }
                    Add-Type -Assembly System.IO.Compression.FileSystem
                    $compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
                    [System.IO.Compression.ZipFile]::CreateFromDirectory($outpath, $zipfile, $compressionLevel, $false)
                }

                $cmdBlock3 = {
                    param([string]$varpath,[string]$guid,[bool]$debug)
                    $zipfile = Join-Path $varpath "$($env:COMPUTERNAME)-$guid.zip"
                    if (-not $debug) {
                        $outpath = Join-Path $varpath $guid
                        Remove-Item $outpath -Recurse -Confirm:$false -Force
                        Remove-Item $zipfile -Confirm:$false -Force
                    } 
                }


                try{
                    $binPath = Join-Path $ToolPath "bin"
                    $exefile = Join-Path $binPath $ToolNameExe
                    $varPath = Join-Path $ToolPath "var"
                    $outpath = Join-Path $varpath $jobGUID
                    $zipfile = Join-Path $varpath "$($TargetServerName)-$jobGUID.zip"
                    $zipPath = (Join-Path "\\$($TargetServerName)" $zipfile).Replace(':','$')

					if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Invoking command on $($TargetServerName)..." | Add-Content -Path $logfile }
					if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Invoking command block: $cmdBlock" | Add-Content -Path $logfile }
                    $cmdBlock1 = [Scriptblock]::Create($cmdBlock)

                    if ($TargetServerName -eq $ENV:ComputerName) {
                        $job1Obj = Invoke-Command -ScriptBlock $cmdBlock1 -ArgumentList($TargetServerName,$ToolName,$exefile,$varpath,$jobGUID,$inParams,$outParams,$HasDebugFlag) 
                        
					    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Compressing files on $($TargetServerName)..." | Add-Content -Path $logfile }
                        $job2Obj = Invoke-Command -ScriptBlock $cmdBlock2 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) 

					    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Copying files from $($TargetServerName)..." | Add-Content -Path $logfile }
                        Copy-Item -Path $zipPath -Destination $destPath

					    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Done copying files from $($TargetServerName)." | Add-Content -Path $logfile }
                        if(-not $HasDebugFlag) {
                            #clean up files on remote servers
                            $job3Obj = Invoke-Command -ScriptBlock $cmdBlock3 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) 
                        }
                    } else {
                        try{
                            $job1Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock1 -ArgumentList($TargetServerName,$ToolName,$exefile,$varpath,$jobGUID,$inParams,$outParams,$HasDebugFlag)  -ErrorAction Stop
                            
					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Compressing files on $($TargetServerName)..." | Add-Content -Path $logfile }
                            $job2Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock2 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) 

					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Copying files from $($TargetServerName)..." | Add-Content -Path $logfile }
                            Copy-Item -Path $zipPath -Destination $destPath

                            if(-not $HasDebugFlag) {
                                $job3Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock3 -ArgumentList($varPath,$jobGUID,$HasDebugFlag)
                            } else {
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Did not clean up working files on $($TargetServerName)" | Add-Content -Path $logfile }
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Files:" | Add-Content -Path $logfile }
						        $tPath = Join-Path "\\$($TargetServerName)" (Join-Path $varpath $jobGUID)
						        $tPath = $tPath.Replace(":","$")
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool]    $tPath"  | Add-Content -Path $logfile }
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool]    $zipPath" | Add-Content -Path $logfile }
                            }
					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Done copying files from $($TargetServerName)." | Add-Content -Path $logfile }
                        } catch {
                            if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Caught exception.  Attempting command with Kerberos authentication..." | Add-Content -Path $logfile }

                            # connect to the computer from client using kerberos as the current user:
                            $job1Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock1 -ArgumentList($TargetServerName,$ToolName,$exefile,$varpath,$jobGUID,$inParams,$outParams,$HasDebugFlag) -Authentication NegotiateWithImplicitCredential

					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Compressing files on $($TargetServerName)..." | Add-Content -Path $logfile }
                            $job2Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock2 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) -Authentication NegotiateWithImplicitCredential

					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Copying files from $($TargetServerName)..." | Add-Content -Path $logfile }
                            Copy-Item -Path $zipPath -Destination $destPath

                            if(-not $HasDebugFlag) {
                                $job3Obj = Invoke-Command -ComputerName $TargetServerName -ScriptBlock $cmdBlock3 -ArgumentList($varPath,$jobGUID,$HasDebugFlag) -Authentication NegotiateWithImplicitCredential
                            } else {
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Did not clean up working files on $($TargetServerName)" | Add-Content -Path $logfile }
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Files:" | Add-Content -Path $logfile }
						        $tPath = Join-Path "\\$($TargetServerName)" (Join-Path $varpath $jobGUID)
						        $tPath = $tPath.Replace(":","$")
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool]    $tPath"  | Add-Content -Path $logfile }
                                if($HasDebugFlag){ "[Invoke-SRxRemoteTool]    $zipPath" | Add-Content -Path $logfile }
                            }
					        if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Done copying files from $($TargetServerName)." | Add-Content -Path $logfile }

                        }
                    }

                    if($HasDebugFlag){ "[Invoke-SRxRemoteTool] Completed invoked $ToolName command on $($TargetServerName) with job id $($jobGUID)." | Add-Content -Path $logfile }

                } catch {
                    $errorfile = Join-Path $destPath "error.log"
                    "[Invoke-SRxRemoteTool] Caught exception while invoking $ToolName command on $($TargetServer.Name)" | Add-Content -Path $errorfile
                    "Exception:" | Add-Content -Path $errorfile 
                    "$_" | Add-Content -Path $errorfile 
                }
            }

            Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] Invoking tool on $($TargetServer.Name)."
            if($HasDebugFlag) {Write-Host "Creating debug file in $destPath"}
            try {
                    $job = Start-Job -Name $TargetServer.Name -ScriptBlock $jobBlock -ArgumentList $($ToolName,$ToolPath,$TargetServer.Name,$global:SRxEnv.RemoteUtilities.$ToolName.Exe,$jobGUID,$destPath,$CmdBlock.ToString(),$InputParams,$OutputParams,$HasDebugFlag)
#                    $job = Start-Job -Name $TargetServer.Name -ScriptBlock $jobBlock -ArgumentList $($jobGUID,$destPath,$InputParams,$HasDebugFlag)
                    $jobList.Add($job) | Out-Null
            } catch {
                Write-SRx ERROR "[Invoke-SRxRemoteTool][$ToolName] Caught exception when starting job."
                Write-SRx ERROR "$job"
                Write-SRx ERROR "[Invoke-SRxRemoteTool][$ToolName] Exception:"
                Write-SRx ERROR "$_"
            }
        } else {
            Write-SRx ERROR "[Invoke-SRxRemoteTool][$ToolName] Unable to invoke tool. The Remote Utility '$ToolName' is not enabled."
        }
    }
    END {
        WaitForJobs -Jobs $jobList

        Write-SRx VERBOSE "[Invoke-SRxRemoteTool][$ToolName] Done collecting data. Extracting..." 
        Add-Type -Assembly System.IO.Compression.FileSystem
        $zipfiles = Get-ChildItem $destPath -Filter "*.zip"
        foreach($f in $zipfiles) {
            [System.IO.Compression.ZipFile]::ExtractToDirectory($f.FullName, $destPath)
            if(-not $HasDebugFlag) {
                $f.Delete()
            }
        }

#        $files = Get-ChildItem $destPath -Filter "$ToolName-*.log"
        $files = Get-ChildItem $destPath 
        $sum = $files | Measure-Object -Property Length -Sum
        $t = $(Get-Date) - $startTime
        if($sum.Sum -gt 1GB) {
            $size = "$("{0:N2}" -f ($sum.Sum/1GB)) GB"
        } elseif($sum.Sum -gt 1MB) { 
            $size = "$("{0:N2}" -f ($sum.Sum/1MB)) MB"
        } else{ 
            $size = "$("{0:N2}" -f ($sum.Sum/1KB)) KB"
        }
        Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] Collected $($files.Count) files totaling $size in $("{0:N2}" -f $t.TotalMinutes) minutes." -ForegroundColor DarkGray


        # if this is a console (not ISE) reset input encoding back to utf8
        # if utf 8 is enabled, it will put a BOM on the script block input for Start-Job and break it
	    if ($Host.Name -eq "ConsoleHost") {
            if([system.console]::InputEncoding -isnot [Text.UTF8Encoding]) {
                [system.console]::InputEncoding=[System.Text.Encoding]::UTF8
            }
        }

        return $files
    }
}

Function WaitForJobs
{
    param(
        [parameter(Mandatory=$true)]
	    [Object[]]$Jobs,
        [switch]$DoNotRemoveJobs
    )

    if($Jobs.Count -eq 0) {
        Write-SRx VERBOSE "[Invoke-SRxRemoteTool][$ToolName] No Jobs found." 
        return
    } else {
        Write-SRx VERBOSE "[Invoke-SRxRemoteTool][$ToolName] Waiting for Jobs..." 
    }

    Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] Created $($jobs.Count) Jobs to collect data. Waiting..." -ForegroundColor Cyan 

    $done = $false
    while(-not $done)
    {
        $completed = $jobs | ? { $_.State -eq "Completed" -or $_.State -eq "Failed" } 
        $count = $completed.Count
        $p = [System.Convert]::ToInt32(($count/$($jobs.Count) * 100))
        Write-Progress -Id 2 -Activity "Waiting for remote jobs... This will take a few minutes." -Status "[$ToolName] - $count of $($jobs.Count) jobs complete"  -PercentComplete $p
        Start-Sleep -Seconds 1
        if($count -ge $jobs.Count){$done = $true}
    }
    Write-Progress -Id 2 -Activity "Waiting for remote jobs... This will take a few minutes." -Completed

    $failedJobs = $jobs | ? { $_.State -eq "Failed" } 
    $failedJobs | % { Write-SRx WARNING "[Invoke-SRxRemoteTool][$ToolName] Job failed on server $($_.Name)"; if($HasDebugFlag){Write-SRx ERROR "$(Receive-Job $_)" }}
    if($failedJobs.Count -eq 0) {
        Write-SRx INFO "[Invoke-SRxRemoteTool][$ToolName] All Jobs completed successfully." -ForegroundColor Green
    }
    if(-not $DoNotRemoveJobs){
        Write-SRx INFO " * [Invoke-SRxRemoteTool][$ToolName] Keeping jobs." -ForegroundColor DarkGray
        $jobs | Remove-Job
    }
}


function Remove-SRxRemoteTool 
{
<#
.SYNOPSIS

.DESCRIPTION

.INPUTS
	
.NOTES

#>
[CmdletBinding()]
param ( 
    [parameter(Mandatory=$true,ValueFromPipeline=$true)]
    $TargetServer,
    [parameter(Mandatory=$true)]
    $ToolName
)
}

function Invoke-SRxRemotePowerShellJobs
{
    [CmdletBinding()]
    param ( 
        [parameter(Mandatory=$true,ValueFromPipeline=$true)]
        $TargetServer,
        [parameter(Mandatory=$true)]
        $Cmdlet
    )
    BEGIN {
        # to be tricky like Brian
        $HasDebugFlag = ($PSCmdlet.MyInvocation.BoundParameters["Debug"].IsPresent -or $global:SRxEnv.Log.Level -eq "Debug")

        $ToolName = $Cmdlet
        Write-SRx INFO "[Invoke-SRxRemotePowerShellJobs][$ToolName] Invoking commands" -ForegroundColor Cyan

        $startTime = Get-Date

        # job list
        $jobList = New-Object System.Collections.ArrayList

        # if utf 8 is enabled, it will put a BOM on the script block input for Start-Job and break it
        # this is not a problem with the ISE, check our host name
	    if ($Host.Name -eq "ConsoleHost") {
            if([system.console]::InputEncoding -is [Text.UTF8Encoding]){
		        [system.console]::InputEncoding= New-Object Text.UTF8Encoding $false
            }
        }
    }
    PROCESS {
        if (-not $TargetServer.canPing()) {
            Write-SRx ERROR "[Invoke-SRxRemotePowerShellJobs][$ToolName] Unable to ping $($TargetServer.Name)"
        } else {
            Write-SRx INFO "[Invoke-SRxRemotePowerShellJobs][$ToolName] Invoking command on $($TargetServer.Name)."
            if($TargetServer.Name -eq $env:COMPUTERNAME){
                $job = Start-Job -ScriptBlock {param($cmd); . $cmd} -ArgumentList ($Cmdlet) -Name $TargetServer.Name;
                $jobList.Add($job) | Out-Null
            } else {
                $job = Invoke-Command -ComputerName $TargetServer.Name -ScriptBlock {param($cmd);. $cmd} -ArgumentList ($Cmdlet) -AsJob -JobName $TargetServer.Name
                $jobList.Add($job) | Out-Null
            }
        }
    }
    END {
        WaitForJobs -Jobs $jobList -DoNotRemoveJobs

        $jobData = $jobList | % { New-Object PSObject -Property @{
            Name = $_.Name;
            Data = Receive-Job -Job $_ ;
        } }
        $jobList | Remove-Job | Out-Null

        $t = $(Get-Date) - $startTime
        Write-SRx INFO "[Invoke-SRxRemotePowerShellJobs][$ToolName] Ran commands on $($jobList.Count) servers in $("{0:N2}" -f $t.TotalMinutes) minutes." -ForegroundColor DarkGray

        # if this is a console (not ISE) reset input encoding back to utf8
        # if utf 8 is enabled, it will put a BOM on the script block input for Start-Job and break it
	    if ($Host.Name -eq "ConsoleHost") {
            if([system.console]::InputEncoding -isnot [Text.UTF8Encoding]) {
                [system.console]::InputEncoding=[System.Text.Encoding]::UTF8
            }
        }

        return $jobData
    }
}


Export-ModuleMember Invoke-SRxRemoteTool
Export-ModuleMember Enable-SRxRemoteTool
Export-ModuleMember Remove-SRxRemoteTool
Export-ModuleMember Invoke-SRxRemotePowerShellJobs

# SIG # Begin signature block
# MIIkpQYJKoZIhvcNAQcCoIIkljCCJJICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBxuWSthfOeD5XE
# 8DA0Rra4te1+Xwv9EUZkux3/3qjDiKCCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWejCCFnYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCCAWkwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEID3BSmrZ
# sS42ov+P8g1/4aEu6whuwvLmWQaM9euWgzT3MIH8BgorBgEEAYI3AgEMMYHtMIHq
# oFaAVABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBs
# AHQAaAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKGBj4CBjGh0
# dHBzOi8vYmxvZ3MubXNkbi5taWNyb3NvZnQuY29tL3NoYXJlcG9pbnRfc3RyYXRl
# Z2VyeS8yMDE2LzAyLzAxL2Fubm91bmNpbmctdGhlLXNlYXJjaC1oZWFsdGgtcmVw
# b3J0cy1zcngtZm9yLXNoYXJlcG9pbnQtc2VhcmNoLWRpYWdub3N0aWNzMA0GCSqG
# SIb3DQEBAQUABIIBAJ70lkB/6Ojckc/OItyHK3i36Z40KIpJpLq1jyJ19LULWFiW
# lSF7v9v5kq9GSNdZpc0UNGvaZYWM2XEJoYsYhJzBpiOLTB0QkrBIWfJi9GKMsOtu
# CedK1g6/n5em0riA7dUcdR5Vpfk36kovUsTWW96ZPLlt8T/LEBmw6n+rN03GcvDB
# 4smivT7DmkBUWCXnMOTmr76kkZ09pLK0seKYFCpZPFvHbreLbU4GlpL7DhIhaCW5
# R+vqp4297HMXFQMUiQ1uZt27Y/oGs+3AylcwitmqN0GfbdBNLQvjSanRKCGp4JHJ
# oAOQY81s+Astcxo5gW6L0dlLP75aMTxE/ELT46ehghNIMIITRAYKKwYBBAGCNwMD
# ATGCEzQwghMwBgkqhkiG9w0BBwKgghMhMIITHQIBAzEPMA0GCWCGSAFlAwQCAQUA
# MIIBPAYLKoZIhvcNAQkQAQSgggErBIIBJzCCASMCAQEGCisGAQQBhFkKAwEwMTAN
# BglghkgBZQMEAgEFAAQgO+nCBlR1ur4Y0JEEv/46h9ovfEWmGnc9q/LwD5CXxYAC
# BltoddhFWBgSMjAxODA4MTcyMjA4MTUuNzlaMAcCAQGAAgH0oIG5pIG2MIGzMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BS
# MScwJQYDVQQLEx5uQ2lwaGVyIERTRSBFU046QjFCNy1GNjdGLUZFQzIxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wggg7MMIIE2jCCA8KgAwIB
# AgITMwAAALFxE3nfdfY1yAAAAAAAsTANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xNjA5MDcxNzU2NTdaFw0xODA5MDcxNzU2
# NTdaMIGzMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMQ0wCwYD
# VQQLEwRNT1BSMScwJQYDVQQLEx5uQ2lwaGVyIERTRSBFU046QjFCNy1GNjdGLUZF
# QzIxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCqpCSUbVjWW7yhvQ/t166a5Gfgm9GL
# YYSuYr3i+BudY+Z3SP/1qsDvnf0cPV2kbW6FhuacDFz6qy68wzR+kS+21MriVlJT
# uyzmsl9aZsWf8nyRIYjwr2IFoHqFCQm4hfiyL2mk2v1Hehkjcdsn/JGQpQ+TiGjO
# ljoKR6FFzT9l+7q1CLKojuYKVdhlNePD6suyHf+B0G9gN3fzMUGWVp/7e6KYpCBR
# NcaNsp+plmTe0RTeJtZU9TECabGUbexZOVeZTfV8LD/pNXMaDbnWWr5Djo6Nt4f2
# 8HZM5yoSyjg1qLcnUJ0wBhR2V6VVW2BB0jH9z7ke+vDRjpbu4YEBadbnAgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQUTlc994suFEtXsvwiXtPPtydEEDswHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEAc+6N+7Rbw8FOmN9ho+sAogEspyWNPj5idZtuAa+Z
# dTw68hQMGSS/yA0YYdE7kNLJJoIBEjOCfbIiF4CqHobAzbIqt9vh5UJg97UJOUKx
# 5LlM6/5Of/3mZeP43FOq+42auGAJWvQJDtvfGgpzANxBuDtOZ6sOBsi/aTtwSpth
# tT8Hcy1JfxmON/RmeB0qhfQliQAQNtlyE6tGJS0Mki16A8pk9/oKN4diOuYrC9M5
# ULO/eVbS7KHXJv84N5Ef5WoQ1IcJugWISKr0qkow6l6TVW9CGYjYptOVG8rzr2CP
# U3C5QcfxzdZe7gDRfX4IGZTy3SC9398WVC/DTi94paH3zjCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCA3UwggJdAgEBMIHjoYG5pIG2MIGzMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMScwJQYDVQQLEx5uQ2lw
# aGVyIERTRSBFU046QjFCNy1GNjdGLUZFQzIxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJBgUrDgMCGgUAAxUAOrrfkyhl5HrT56P2
# 4qdEbliqU9KggcIwgb+kgbwwgbkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xDTALBgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIgTlRTIEVT
# Tjo1N0Y2LUMxRTAtNTU0QzErMCkGA1UEAxMiTWljcm9zb2Z0IFRpbWUgU291cmNl
# IE1hc3RlciBDbG9jazANBgkqhkiG9w0BAQUFAAIFAN8hfOkwIhgPMjAxODA4MTgw
# MDU3MTNaGA8yMDE4MDgxOTAwNTcxM1owczA5BgorBgEEAYRZCgQBMSswKTAKAgUA
# 3yF86QIBADAGAgEAAgFRMAcCAQACAhgnMAoCBQDfIs5pAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwGgCjAIAgEAAgMW42ChCjAIAgEAAgMHoSAwDQYJ
# KoZIhvcNAQEFBQADggEBAH7vbU01AwPS/oKm1oMakLfn+RqiHE/DeEpDC2PGhjMC
# muLibEYANDuiWNK/RIkVgAz9BIZM0Ztfo8QXCNheFy18OIdcdMEVw0J7PXnl7gUs
# cu1L384qeyDzzpRbUPfJgo1XQUqEFZXqXJjgFti1B0iK0lGT+q7q6ynWqRbmLfux
# qReLbpOiGUd0LN0lEGiYe332fiWSXV3+2wL41a5o+E75v7xRr0Q7a10CjEKvxL5J
# QgDeMxY/FtdrQKX3HpaOUbqyM7H+H6DHk6+RFeP3KTE8HvPkXXGxNh85B+Zwcfb+
# BAtvPANuLI+MaZLNMrzz6sfgAyzT9S79AZ4nXKcNhZwxggL1MIIC8QIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAALFxE3nfdfY1yAAAAAAA
# sTANBglghkgBZQMEAgEFAKCCATIwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCD75SF63K+ziXu/ijRMf6mGVm1M24IITpqFTqj4NYR/
# 7TCB4gYLKoZIhvcNAQkQAgwxgdIwgc8wgcwwgbEEFDq635MoZeR60+ej9uKnRG5Y
# qlPSMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAACx
# cRN533X2NcgAAAAAALEwFgQUZ1WtjuiyZlDKvuNO96Rg56k9FbYwDQYJKoZIhvcN
# AQELBQAEggEAdF4qOqhmmnwaE9kC/dco7yCZ3L0yd91rH0bUnaPpRsoENpQBuNFo
# DZYG8H4WfsIDhDVxRf4MmV0rdJRYAGTjSgDX2KUciTNtt/gasoZiJqWHMVSVBc6J
# 9i1DDncmlyvaDlaYd0sAYEJIyI+OE29PExMdvXr7b2WT5/MXnaPMCE7RytprbXcT
# aUuZ+wobr4Yv6odMFf+wfWhZnb4cWSRKhSKiGR18WBjqS1QC5WBBjomEXYBIx1ZO
# P/le9JVEpjWOfx7VThzET8Q3bZRr8bGNd8QkY03YSBnuF66WmEWwlfw7Z6vD5etM
# lmiXfMoa+IgdmDvKEETFWYyH9pK/RQfEbQ==
# SIG # End signature block
