<#
.SYNOPSIS 
    SRx Dashboard Configuration Script
    	
.DESCRIPTION 
	Internal script for bootstrapping the Dashboard configuration
		
.NOTES
	=========================================
	Project		: Search Health Reports (SRx)
	-----------------------------------------
	Requires	: 
		PowerShell Version 3.0, Search Health Reports (SRx), Microsoft.SharePoint.PowerShell,
        SharePoint Search Health (SRx) Dashboard license

	========================================================================================
	This Sample Code is provided for the purpose of illustration only and is not intended to 
	be used in a production environment.  
	
		THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY
		OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

	We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to 
	reproduce and distribute the object code form of the Sample Code, provided that You agree:
		(i) to not use Our name, logo, or trademarks to market Your software product in 
			which the Sample Code is embedded; 
		(ii) to include a valid copyright notice on Your software product in which the 
			 Sample Code is embedded; 
		and 
		(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against
              any claims or lawsuits, including attorneys' fees, that arise or result from 
			  the use or distribution of the Sample Code.

	========================================================================================
	
.INPUTS
    input1

.EXAMPLE
	Module-Name

#>
if($global:SRxEnv.Exists) 
{
    Write-SRx VERBOSE $("[Post Init Script] Dashboard Config") -ForegroundColor DarkCyan
    $previousState = ($global:SRxEnv.Dashboard.Initialized)
	$global:SRxEnv.Dashboard.Initialized = $((-not $global:SRxEnv.Dashboard.UpdateHandle) -and 
											($global:SRxEnv.Dashboard.Site -ne $null) -and 
											($global:SRxEnv.Dashboard.Handle -ne $null))

    if (($global:SRxEnv.Dashboard.UpdateHandle -ne $null) -and ($global:SRxEnv.Dashboard.UpdateHandle -is [bool])) 
	{
        $global:SRxEnv.Dashboard.PSObject.Properties.Remove("UpdateHandle")
    }

    $isNowBusted = $( ($previousState) -and ($previousState -ne $global:SRxEnv.Dashboard.Initialized) ) 
    $isNowInitialized = $( ($global:SRxEnv.Dashboard.Initialized) -and ($global:SRxEnv.Dashboard.Initialized -ne $previousState) ) 

    #-- If now busted, persist the Dashboard config to file (assuming the config file is not inaccessible) ---            
	if ($isNowBusted -or $isNowInitialized) 
    { 
		Write-SRx VERBOSE $(" --> Updating the 'initialized' state for the Dashboard")
        $global:SRxEnv.PersistCustomProperty("Dashboard", $( $global:SRxEnv.Dashboard ))
	}
			
    if ($xSSA._hasSRx) 
    {
        if ([string]::isNullOrEmpty($global:SRxEnv.SSA)) 
        {
            Write-SRx VERBOSE $(" --> Setting Default SSA: " + $xSSA.Name) -ForegroundColor Cyan
            $global:SRxEnv.PersistCustomProperty("SSA", $xSSA.Name)
        }
                
        $configuredHandleCount = $( if ($global:SRxEnv.HandleMap -is [Hashtable]) { 1 } 
                                    elseif($global:SRxEnv.HandleMap -is [PSCustomObject]) { 1 } 
                                    else {$global:SRxEnv.HandleMap.count} 
                                    )
        if ($global:___SRxCache.SSASummaryList.count -ne $configuredHandleCount)
        {
            Write-SRx VERBOSE $(" --> " + $(if ($configuredHandleCount -eq 0) {"B"} else {"Reb"}) + " uilding the `$SRxEnv.HandleMap")
            $SRxEnv.h.BuildHandleMappings()
        }

        if ($xSSA.name -ne $global:SRxEnv.SSA) 
        {    
            Write-SRx VERBOSE $(" --> Setting new Default SSA: " + $xSSA.Name + "  (replacing '" + $global:SRxEnv.SSA + "')") -ForegroundColor Cyan
            $global:SRxEnv.SetCustomProperty("SSA", $xSSA.name)
        }

        $mappedHandle = $($global:SRxEnv.HandleMap | Where { $_.Name -eq $xSSA.name }).Handle
        if ($mappedHandle.count -gt 1) {
            Write-SRx WARNING $(" --> Multiple SSAs map to '" + $xSSA.name + "' ...ignoring map")
            $mappedHandle = ""
        }
                    
        if ([string]::isNullOrEmpty($mappedHandle)) {
            #This will trigger an Enable-SRxDashboard below
            Write-SRx VERBOSE $(" --> No handle configured, triggering Enable-SRxDashboard")
            $global:SRxEnv.SetCustomProperty("Dashboard.Initialized", $false)
        } else {
            #Just logically update the $SRxEnv.Dashboard (but this will not persist to custom.config.json)
            Write-SRx VERBOSE $(" --> Updating `$SRxEnv.Dashboard.Handle with " + $mappedHandle)
            $global:SRxEnv.SetCustomProperty("Dashboard.Handle", $mappedHandle)
        }
    }

	if ($global:SRxEnv.Dashboard.Initialized) 
	{
        Write-SRx Info "SRx Search Dashboard Site: " -ForegroundColor DarkCyan -NoNewline
		Write-SRx Info $global:SRxEnv.Dashboard.Site
        Write-SRx Info "SRx Search Dashboard Handle: " -ForegroundColor DarkCyan -NoNewline
		Write-SRx Info $global:SRxEnv.Dashboard.Handle

		Write-SRx Verbose "Run the command 'Enable-SRxDashboard' to change the Dashboard settings."
        if ($SRxEnv.SilentLicenseAccepted)
        {
            Write-SRx INFO $("-" * 32) -ForegroundColor DarkCyan
			Write-SRx INFO $("-- Initializing SRx Dashboard --") -ForegroundColor DarkCyan
			Write-SRx INFO $("-" * 32) -ForegroundColor DarkCyan
			Write-SRx INFO
					
            Enable-SRxSilentInstall -Site $SRxEnv.SilentSite -Handle "$($SRxEnv.SilentHandle)" -SSA "$($SRxEnv.SilentSSA)" -ThirdPartyLibrariesAccepted:$SRxEnv.SilentThirdPartyLibrariesAccepted -LicenseAccepted:$SRxEnv.SilentLicenseAccepted -ScheduledTasksPassword $SRxEnv.SilentScheduledTasksPassword -ScheduledTasksUser $SRxEnv.SilentScheduledTasksUser -IsHybrid $SRxEnv.SilentIsHybrid
        }
	}
	elseif ((Get-Module "Enable-SRxDashboard") -ne $null) 
	{
        if ($global:SRxEnv.CustomConfigIsReadOnly) 
        {
			Write-SRx Warning $("~~~ The custom config file is currently inaccessible; skipping Dashboard initialization...")
        }
        elseif ($SRxEnv.SilentLicenseAccepted)
        {
            Write-SRx INFO $("-" * 32) -ForegroundColor DarkCyan
			Write-SRx INFO $("-- Initializing SRx Dashboard --") -ForegroundColor DarkCyan
			Write-SRx INFO $("-" * 32) -ForegroundColor DarkCyan
			Write-SRx INFO
					
            Enable-SRxSilentInstall -Site $SRxEnv.SilentSite -Handle "$($SRxEnv.SilentHandle)" -SSA "$($SRxEnv.SilentSSA)" -ThirdPartyLibrariesAccepted:$SRxEnv.SilentThirdPartyLibrariesAccepted -LicenseAccepted:$SRxEnv.SilentLicenseAccepted -ScheduledTasksPassword $SRxEnv.SilentScheduledTasksPassword -ScheduledTasksUser $SRxEnv.SilentScheduledTasksUser -IsHybrid $SRxEnv.SilentIsHybrid
        }
        elseif ([Environment]::UserInteractive)
        {
            Write-SRx INFO $("-" * 32) -ForegroundColor DarkCyan
			Write-SRx INFO $("-- Initializing SRx Dashboard --") -ForegroundColor DarkCyan
			Write-SRx INFO $("-" * 32) -ForegroundColor DarkCyan
			Write-SRx INFO
					
			Enable-SRxDashboard
        }
	}  
	else
	{			    
		Write-SRx INFO $(" -- Contact SearchEngineers@microsoft.com to enable Dashboard, Alerts, and Monitoring features") -ForegroundColor White -BackgroundColor DarkMagenta 
	}
}
# SIG # Begin signature block
# MIIkwQYJKoZIhvcNAQcCoIIksjCCJK4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCUQwxE2KC2yaUA
# M/O4gMD38l8gQrdga7XIH6hnmSjObqCCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWljCCFpICAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCCAWkwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEyFpVNv
# yIoJOgkvANqfcUdOCl45/iTGRcgHCnjNHrEGMIH8BgorBgEEAYI3AgEMMYHtMIHq
# oFaAVABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBs
# AHQAaAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKGBj4CBjGh0
# dHBzOi8vYmxvZ3MubXNkbi5taWNyb3NvZnQuY29tL3NoYXJlcG9pbnRfc3RyYXRl
# Z2VyeS8yMDE2LzAyLzAxL2Fubm91bmNpbmctdGhlLXNlYXJjaC1oZWFsdGgtcmVw
# b3J0cy1zcngtZm9yLXNoYXJlcG9pbnQtc2VhcmNoLWRpYWdub3N0aWNzMA0GCSqG
# SIb3DQEBAQUABIIBAAqvUJ3bHVihFxB9RGym/1mmoKLJ9gJjgQ12iB7aTd7IdWQm
# ripVBAj5T12oghvxdMEfBamw8bMuu+XaCk8IHhhwFITg/prL0SYdJhHGPeFvZEPQ
# bf5S68N79otn6czVI6P0J8I/NOE/9n50o5Vt6HX1N63J1G9dTicpbeD3VWIgzRgL
# TsbEiV0mDtEjv22t9N/IistK354ZSg73bzSELjDqxzBqPyKfNGGuq7fITJRRKPp4
# BHd/OgAa/xu/c/PrSaqRzDeHk6tY+aP07x38u8QklDyBXwMC+XKBEJ+hmwujopXs
# egSEjZvIvNiZ2sJHFPj18Rc7Z9tusN+lyl6FRYyhghNkMIITYAYKKwYBBAGCNwMD
# ATGCE1AwghNMBgkqhkiG9w0BBwKgghM9MIITOQIBAzEPMA0GCWCGSAFlAwQCAQUA
# MIIBPQYLKoZIhvcNAQkQAQSgggEsBIIBKDCCASQCAQEGCisGAQQBhFkKAwEwMTAN
# BglghkgBZQMEAgEFAAQgZO8fVrc2IEKKzxl6J8FT5z5wGqIfkkbyOKoxa+6/PEYC
# Blt11bQj8RgTMjAxODA4MTcyMjA4MDEuODcxWjAHAgEBgAIB9KCBuaSBtjCBszEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9Q
# UjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNOOjk4RkQtQzYxRS1FNjQxMSUwIwYD
# VQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIOzzCCBNowggPCoAMC
# AQICEzMAAACdIJxWd1XUKJoAAAAAAJ0wDQYJKoZIhvcNAQELBQAwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTYwOTA3MTc1NjQxWhcNMTgwOTA3MTc1
# NjQxWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsG
# A1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNOOjk4RkQtQzYxRS1F
# NjQxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0kSYnBFaKhouqp9TXW1dvLZZdpHA
# JlsD5shsX6Mq60wARnQ4FL8qeF2wI0zsbmBI7EnkW3WmcP3z1K5Vbo69BB9nPRn9
# MXKClKFzsS688BzU2+8huMaptMbCRgcumcw+IQvDLkjfDGp1xTWO11mcqztIfp6y
# 4PxUlt4TRzlC0G7WS/2/DKTwC+X66MiIi+6c+3XhxEvoyw5kzlfeYKh6Ss5lHLhl
# liNiO38FT1lm3ekN1fh8vsBM3nsKlhvMVTkEbwYIQTi79RnftXoEdwUc4uyMx/Gx
# ml5HbsyyHqPalniB7vAHmIBRvroKFB5+njpZJKFXcwz+QUROlsJUUQ+pxQIDAQAB
# o4IBGzCCARcwHQYDVR0OBBYEFLyGCMpbalrK5L3My4K0FUjqh+WhMB8GA1UdIwQY
# MBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6
# Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBD
# QV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# DQYJKoZIhvcNAQELBQADggEBAH/eJCG9We+01otxylmRvi6oRoK7j99kHX3mKgu8
# KGdL/vl3v7X0TqT96EoPPmcis1aJbZcIWuwjFPV5KhNXjJIXnQYh6vOo6hs73NuE
# mkv3chX2n48nqP+l4tYgiZVNQKkVYF65lwHXMAv/QmprVtnsWlw2A4DMFi1qwbkz
# ZE/bXmt/2G/AroGlOO06zl1yGoxMFctfk4yy3aoALeP9ZCipqb4QHf4V3CePH46k
# A+qON9sEJVMf4TJ69zsikMzcKg3BXoYJ1T5W76sloHrLMkBY9r0JW7bJ/3tHeXSG
# pYad2CINV17hqA3GJk4C9v069gGs95e8uZEOYdud0++mNmkwggZxMIIEWaADAgEC
# AgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0
# aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEy
# MTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCC
# hfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRU
# QwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FU
# sc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBX
# day9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4
# HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCC
# AeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2ha
# hW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNV
# HRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYG
# A1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3Js
# L3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcB
# AQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kv
# Y2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUw
# gZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0
# HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0
# AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1
# Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRg
# Eop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X
# 9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbl
# jjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQ
# eKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ou
# OVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+9
# 8eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUB
# HoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ay
# p0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXj
# ad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb
# 01+P3nSISRKhggN4MIICYAIBATCB46GBuaSBtjCBszELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNp
# cGhlciBEU0UgRVNOOjk4RkQtQzYxRS1FNjQxMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBTZXJ2aWNloiUKAQEwCQYFKw4DAhoFAAMVABgNrLOMaDCz+HQZ
# snjOgCs1Lwj6oIHCMIG/pIG8MIG5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMScwJQYDVQQLEx5uQ2lwaGVyIE5UUyBF
# U046NTdGNi1DMUUwLTU1NEMxKzApBgNVBAMTIk1pY3Jvc29mdCBUaW1lIFNvdXJj
# ZSBNYXN0ZXIgQ2xvY2swDQYJKoZIhvcNAQEFBQACBQDfIXzzMCIYDzIwMTgwODE4
# MDA1NzIzWhgPMjAxODA4MTkwMDU3MjNaMHYwPAYKKwYBBAGEWQoEATEuMCwwCgIF
# AN8hfPMCAQAwCQIBAAIBVgIB/zAHAgEAAgIZEDAKAgUA3yLOcwIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMBoAowCAIBAAIDFuNgoQowCAIBAAIDB6Eg
# MA0GCSqGSIb3DQEBBQUAA4IBAQCc4GH1+13CQ6m2iF7EYrYyJpIbK8cE/fMO/axC
# D9EI9BdCx1rYzjdH8mycOnXKh+6LFurVlixg60YJStteFd84Z95YPgcp+0azLGRA
# kAcbX6/sAsOh0AlDlT4VEeMfhcFKW6HAFLYPUY9LixO3VRrAbGfO6C5+2XqkoU2M
# tCv7pbCxvE+35cletBazFeXr+T2wB2hTvGhsPsQAb+YUmnKD476tk+OlHbTnFG1V
# 8EkZhojOJruCv1OLAgWIOkeis1UFPZCuysp1s8WmK+/5MLWyNx15UOAfJe/lBCh6
# LleqlBtmN6gw1NNYH2SB+6fDND1cOPCG07c4qBwnR4neW8B4MYIDDTCCAwkCAQEw
# gZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAACdIJxWd1XUKJoA
# AAAAAJ0wDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAvBgkqhkiG9w0BCQQxIgQg/JOQLNW9lY3utnAwq6/6rCMmeGz41Z4rEBOM
# 2s9ezZ0wgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCO+T9XlT9vgM/75WQ4
# N7tHSc+8TGVvcOLxWCd9pCapHDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwAhMzAAAAnSCcVndV1CiaAAAAAACdMCIEIDYIIJMfr8RX3BENtWgf
# 3lBFVLVZWgAjwSTmC74+NXpgMA0GCSqGSIb3DQEBCwUABIIBAA7Ye0g1EcFz+aqy
# RifB4/No2ApXctiN7MEyCUa0kV5mnsv1E6UPV86UydKlMMVd+sm1aenuRFywf3r0
# B660OVSoqFzCijuWCKaWunHRdf5euMoSt5z3SVNH3GefMjEv/zorSN2Mo3hugTyG
# OUixDCaQMOVS5kZOttl5dI1hcQhMBHLjPM4ut0E15SAdhvHRvV6LpYcNWgbGGjIH
# nl4h8lz4VQe2hGS5VhiPPt3H6bN/CHErkgUHLQSkggSH7XdrDb9/s+Kczc4xOakx
# A8qomOu6WokDegnM9oOjzyalF+dXcHAJ5UViSbYEK6Y+TdWOswIHmxG63sYyhvm8
# eBx8C6w=
# SIG # End signature block
