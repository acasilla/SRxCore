SELECT *
FROM [**SEARCHADMIN**].[dbo].[MSSBestBets] AS hist WITH (nolock)
