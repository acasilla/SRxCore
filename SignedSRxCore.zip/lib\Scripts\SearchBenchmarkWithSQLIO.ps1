<#
.SYNOPSIS
    This tool is for measuring I/O performance on ESP, SP2010, and SP2013 servers.
.DESCRIPTION
    This tool is for measuring I/O performance on ESP, SP2010, and SP2013 servers.
    There are several items to consider when running the script:
    1. Set the duration for the main tests. The default is 10 minutes -TestDurationInSeconds 600
    2. Choose the disk you need to test. The script by default runs in the directory c:\sqliotesting. 
	   Change the directory and path to test with the parameter �-drivePathToTest s:\sqliotesting� 
    3. Correctly set the size of the dat file. Specify the DAT file size with the script parameter -DatFileSize. 
	   The valid values are 2GB, 20GB, 250GB, or Custom.
    4. Choose the iops suite to run. Either sp2010 (ESP/SharePoint 2010) or sp2013 (SharePoint 2013.)
    5. To properly exercise a SAN, you should run the tool concurrently on all search servers.

    The script creates a large DAT file to assist in the benchmark testing. Specify the DAT file size with the script parameter -DatFileSize. 
	The valid values are 2GB, 20GB, 250GB, or Custom. There is no support, yet, in the script to automatically figure out the size of the dat file. 
	This is because there are a few items to consider. To correctly set the size of the dat file you need to analyze the size of your disks. 
	The dat file should be about 25% of the size of your drive. Note: It is best to have about half of the drive space full. 
	For example: if you have a 1 TB drive, there should be 500 GB free space and the dat file should be 250 GB. 
	You could use the script to generate dat files and fill the free space to 50%. 

.EXAMPLE
Run a quick benchmark to verify everything works.
.\SearchBenchmarkWithSQLIO.ps1 -DrivePathToTest D:\sqlio2GBtest -TestDurationInSeconds 30 -DatFileSize 2GB

.EXAMPLE
Run a 10 minute test: 
.\SearchBenchmarkWithSQLIO.ps1 -DrivePathToTest D:\sqlio20GBtest -TestDurationInSeconds 600 -DatFileSize 20GB

.EXAMPLE
Run a 10 minute test concurrently on all index servers: 
.\SearchBenchmarkWithSQLIO.ps1 -DrivePathToTest D:\sqlio20GBtest -TestDurationInSeconds 600 -DatFileSize 20GB -serverFile .\servers.txt -RunRemote

.EXAMPLE
Only generate the report: 
.\SearchBenchmarkWithSQLIO.ps1 -OnlyGenerateReports

.EXAMPLE
Collect the cab files from all remote servers: 
.\SearchBenchmarkWithSQLIO.ps1 -OnlyCollectTestData -serverFile .\servers.txt

.EXAMPLE
Cleanup the cab files from all servers
.\SearchBenchmarkWithSQLIO.ps1 -deletecabFiles -serverFile .\servers.txt

.LINK
http://gallery.technet.microsoft.com/ScriptCenter
.NOTES
  File Name : SearchBenchmarkWithSQLIO.ps1
  Author    : Brent Groom, Mikkel Conradi
  SQLIO Parameters: http://sqladm.blogspot.com/2011/04/sqlio-batch.html
#>

<#

  # TODO use the folder name as the sample name and create the search center, document workspace, load the docs. 
  #      Only load the docs if it the inital create or if the user passes a force reload command
  # - Load in a query test file, issue each query and show pass or fail for each one
  # psremoting can't handle block comments. 
    - handle running both types of tests i.e. pass in both sp2013 and 2010 flags
	- Check the target drive to make sure there is sufficient space for the dat file we are about to generate
    - add a flag to repeat test 10X in a row to see if perf is consistent
    - Use sysinternals tool to steal memory
    - look at amount of memory and create a file 10X
    - Check is anti virus is running
	- run test against all drives unless specified. you should implement a drive space available check first
    - check disk layout
	- Add a flag to test ESP IO. Just change report title to ESP and use SP2010 benchmark settings
    - display memory - bginfo stuff
    - Show timestamp of execution
    - Show size and location of dat file
	- Add a -silent flag to bypass the duration warning/prompt
    - allow flags for choosing size of dat file
    - Display readme info with best practices. When testing a SAN have all writing for a 
        long time with one server performing a read
    - Add a duration column in the report
    - Add the size of the dat file as a column on the report
    - Add Bginfo data to the report. Drive sizes, drive space used, ram, etc
    - Add a parameter for dat file size
    - Analyze disk space and recommend a size for the dat file
    - Copy generated cab file to a network share
    - Add text commentary like this email to a readme file, or to the description section of the script.
    - order report table by servername and timestamp
#>
param( [switch]$OnlyGenerateReports,
       [switch]$OnlyCollectTestData,
       [switch]$OnlyCleanupOldTestData, 
       [String]$DrivePathToTest="c:\sqliotesting",
       [switch]$KeepTestFile, # Set this flag so that the test file is not regenerated every time
       [string] [ValidateSet("2GB", "20GB", "250GB")] $DatFileSize="2GB", # This is the size of the DAT file. It must be of sufficient size to accurately test the disks. Valid values for this parameter are 2GB, 20GB, 250GB, Custom
       [string]$TestDurationInSeconds="60",	           
       [switch]$deletecabFiles,
	   [string]$NetworkShareForTestData,	   
 	   [string]$cabFilesDir,	   
       [switch]$Verbose,
	   [string][ValidateSet("SP2010", "SP2013")] $ReportType="SP2013",
	   [switch]$RunRemote,
	   [string]$serverFile = 'servers.txt' # This file is for storing a list of all the remote servers to run tests on
		)

# TODO: 
#  - allow install of SQLIO from a network share
#  - Find install location of SQLIO in case it was manually installed to another location.
#  - Check for an empty dat file. This could happen if there is not enough room on the disk.
#  - Roll TestSQLIO and mexec into this file.
#  - make a test type parameter: Small, Med, Large for 2GB 60 seconds, 20GB 10 min, 250 GB 10 min
 
$global:Debug = $true 
$global:DatFileSize = $DatFileSize
$global:deletecabFiles = $deletecabFiles
$global:KeepTestFile = $KeepTestFile
$global:Cleanup = $OnlyCleanupOldTestData
$global:OnlyGenerateReports = $OnlyGenerateReports
$global:OnlyCollectTestData = $OnlyCollectTestData
$global:TestDurationInSeconds = $TestDurationInSeconds
$global:NetworkShareForTestData = $NetworkShareForTestData
$global:drivePathToTest = $drivePathToTest
$global:runRemote = $RunRemote
$global:templogfiles = "$pwd\templogfiles"
$global:Verbose = $Verbose
$global:serverFile = $serverfile
$global:servername = "$($env:computername)_$((get-date).ToString(�yyyy-MM-dd-HH-mm�))"
$global:extractedLogFilesDir = "$pwd\cabcontents"

if(($cabFilesDir -ne $null) -and ($cabFilesDir.length -gt 0))
{
	$global:cabFilesDir = $cabFilesDir
}
else
{
	$global:cabFilesDir = "$pwd\cabfiles"
}

$global:SP2013 = $true
$global:SP2010 = $false
if($ReportType -eq "SP2010") {
$global:SP2013 = $false
$global:SP2013 = $true
}

$global:sp2013serverList = @()
$global:sp2010serverList = @()
$global:a_1k_read = @{}
$global:a_32k_read = @{}
$global:a_64k_read = @{}
$global:a_32k_write = @{}
$global:a_256k_write = @{}
$global:a_100mb_read = @{}
$global:a_100mb_write = @{}
$global:a_testfilesize = @{}
$global:a_testduration = @{}
$global:a_testserverdisklayout = @{}
$global:a_testserverram = @{}
$global:str_warningMessageForDuration = "WARNING: This test run was set to execute for less than 60 seconds. The recommended minimum is ten minutes or 600 seconds. Consider using the parameter -TestDurationInSeconds 600"
$global:str_warningMessageForFilesize = "WARNING: The dat file should be about 25% of the size of your drive. See report guidance section for more information."
$global:str_reportGuidanceSection = @" 
There is no support, yet, in the script to automatically resolve the size of the dat file. This is because there are a few items to consider. To correctly set the size 
of the dat file you need to analyze the size of your disks. The dat file should be about 25% of the size of your drive. Note: It is best to have about half of
the drive space full. For example: if you have a 1 TB drive, there should be 500 GB free space and the dat file should be 250 GB. You could use the script to 
generate dat files and fill the free space to 50%. 

Specify the DAT file size with the script parameter -DatFileSize. The valid values are 2GB, 20GB, 250GB, or Custom. 

 <br>

"@


function logDebug([String] $strin)
{

	if($global:debug)
	{
		"[$($env:computername)]:$strin"
	}
}

function logInfo([String] $strin)
{
		"[$($env:computername)]:$strin"
}

##############################################
##
## param file functions. These are for setting the size of the DAT file
##

function chooseParamFile()
{
 	logDebug("starting function chooseParamFile")
   # Check available disk space and copy the appropriate param file
	if($($global:DatFileSize) -eq "2GB")
	{
        write-host "Info: Using 2 GB DAT file " -Foregroundcolor green
		copy "$pwd\sqlio\param2gb" "$pwd\sqlio\param"
	}
	elseif($($global:DatFileSize) -eq "20GB")
	{
        write-host "Info: Using 20 GB DAT file " -Foregroundcolor green
		copy "$pwd\sqlio\param20gb" "$pwd\sqlio\param"
	}
	elseif($($global:DatFileSize) -eq "250GB")
	{
        write-host "Info: Using 250 GB DAT file " -Foregroundcolor green
		copy "$pwd\sqlio\param250gb" "$pwd\sqlio\param"
	}
	elseif($($global:DatFileSize) -eq "custom")
	{
        write-host "Info: Using DAT file settings as defined in file: $($pwd)\sqlio\paramCustom" -Foregroundcolor green
		copy "$pwd\sqlio\paramCustom" "$pwd\sqlio\param"
	}
	else
	{
        write-host "Warning: No size was specified for the DAT file. Please specify 2GB, 20GB, 250GB, or custom. Using default size of 20GB" -Foregroundcolor yellow
		copy "$pwd\sqlio\param20gb" "$pwd\sqlio\param"
	}

}

function createParamFiles()
{
	logDebug("starting function createParamFiles")
    $checkDriveToTest = Test-Path "$($global:drivePathToTest)"
	if(!$checkDriveToTest)
    {
        $newdir = md "$($global:drivePathToTest)"
    }
    
    # Out-File -filepath $ddfFile -encoding ASCII -append
    "$($global:drivePathToTest)\testfile.dat 2 0x0 2040" | out-file "$pwd\sqlio\param2gb" -encoding ASCII
    "$($global:drivePathToTest)\testfile.dat 2 0x0 20480" | out-file "$pwd\sqlio\param20gb" -encoding ASCII
    "$($global:drivePathToTest)\testfile.dat 2 0x0 204800" | out-file "$pwd\sqlio\param250gb" -encoding ASCII

    # check to see if a custom file exists. if it doesn't, then create it with a size of 20GB
	$boolParmFileExists = Test-Path "$($pwd)\sqlio\paramCustom"
	if(!$boolParmFileExists)
	{
		"Info: Creating default paramCustom file"
        "$($global:drivePathToTest)\testfile.dat 2 0x0 20480" | out-file "$pwd\sqlio\paramCustom" -encoding ASCII
	}

}

##
##
##
##############################################

function cleanLogs()
{
	logDebug("starting function cleanLogs")
    logInfo("Removing old log files from $($global:templogfiles)")
    if(Test-Path "$($global:templogfiles)")
    { 
        Remove-Item "$($global:templogfiles)" -recurse -force
        $newdir = md "$($global:templogfiles)"
    }
	cleanup
}

function cleanup()
{
	logDebug("starting function cleanup")
    logInfo("Cleaning up temporary log files")
	if($global:Cleanup)
	{
		logInfo("Cleaning up all test data from previous runs. ")
		logInfo("Cleaning up $($global:cabfilesDir)")
		if(Test-Path "$($global:cabfilesDir)")
		{ 
			Remove-Item "$($global:cabfilesDir)" -recurse -force
		}
		if(($($global:NetworkShareForTestData) -ne $null) -and ($($global:NetworkShareForTestData).length -gt 0) -and (Test-Path "$($global:NetworkShareForTestData)"))
		{ 
			logInfo("Cleaning up $($global:NetworkShareForTestData)")
			Remove-Item "$($global:NetworkShareForTestData)" -recurse -force
		}
		logInfo("Cleaning up $($global:extractedLogFilesDir)")
		if(Test-Path "$($global:extractedLogFilesDir)")
		{ 
			Remove-Item "$($global:extractedLogFilesDir)" -recurse -force
		}		

		
	}

#    if(Test-Path "$pwd\sqlio\testfile.dat"){ Remove-Item "$pwd\sqlio\testfile.dat"}
#    if(Test-Path "$pwd\sqlio\param2gb"){ Remove-Item "$pwd\sqlio\param2gb"}
#    if(Test-Path "$pwd\sqlio\param20gb"){ Remove-Item "$pwd\sqlio\param20gb"}
#    if(Test-Path "$pwd\sqlio\param250gb"){ Remove-Item "$pwd\sqlio\param250gb"}

    
}

function createCabFile()
{
	logDebug("starting function createCabFile")
    $testfileexists = Test-Path "$($global:cabFilesDir)"
    if(!$testfileexists)
    {
        $newdir = md "$($global:cabFilesDir)"
    }

   New-DDF "$($global:cabFilesDir)" "$($global:templogfiles)" -debug 
  
}

function DisplayUserFeedback()
{
	logDebug("starting function DisplayUserFeedback")

    if([int]$($global:TestDurationInSeconds) -lt 60)
    {        
        write-host "$global:str_warningMessageForDuration" -Foregroundcolor red	
    }
}

function downloadAndInstallSQLIO()
{    
	logDebug("starting function downloadAndInstallSQLIO")
    $testfileexists = Test-Path "$pwd\sqlio\sqlio.exe"
    if(!$testfileexists)
    {
        logInfo("Couldn't find SQLIO at $pwd\sqlio\sqlio.exe")
        $testsqlfolderexists = Test-Path "$pwd\sqlio"
        if(!$testsqlfolderexists)
        {
            logInfo("Installing SQLIO")
            $newdir = md "$pwd\sqlio"
        }

        $testmsifileexists = Test-Path "$pwd\sqlio\sqliomsi.msi"
        if(!$testmsifileexists)
        {    
            $sqliomsi = "http://download.microsoft.com/download/f/3/f/f3f92f8b-b24e-4c2e-9e86-d66df1f6f83b/SQLIO.msi"
            logInfo("Downloading $sqliomsi")
            (New-Object Net.WebClient).DownloadFile($sqliomsi,"$pwd\sqlio\sqliomsi.msi") 
            sleep 5
        }
        
        logInfo("Installing SQLIO")
        msiexec /i "$pwd\sqlio\sqliomsi.msi" /quiet
               
        sleep 15 
        $testsqliofileexists = Test-Path "C:\Program Files (x86)\SQLIO"
        if($testsqliofileexists)
        {
            logInfo("copying sqlio.exe")
            copy "C:\Program Files (x86)\SQLIO\*.*" -destination "$pwd\sqlio" -recurse
            logInfo("Done with SQLIO install")
        }
    }

    $testfileexists = Test-Path "$pwd\sqlio\sqlio.exe"
    if(!$testfileexists)
    {
        logInfo("ERROR: sqlio failed to install. Are you logged on as an administrator?")        
        exit
    }
    
    #$testfileexists = Test-Path "$pwd\sqlio\Bginfo.exe"
    #if(!$testfileexists)
    #{
    
    #   $bginfo = "http://live.sysinternals.com/Bginfo.exe"
    #   "Downloading $bginfo"
    #   (New-Object Net.WebClient).DownloadFile($bginfo,"$pwd\sqlio\Bginfo.exe") 
    #}
    
}

Function pushCabFilesToNetworkShare()
{
	ls "$($global:NetworkShareForTestData)"
	logDebug("starting function pushCabFilesToNetworkShare")
	if(($($global:NetworkShareForTestData) -ne $null) -and ($($global:NetworkShareForTestData).length -gt 0) -and ( Test-Path "$($global:NetworkShareForTestData)"))
	{
		$fileEntries = [IO.Directory]::GetFiles("$($global:cabFilesDir)"); 
		if($fileEntries.length -gt 0)
		{
			foreach($cabfile in $fileEntries) 
			{ 
				#copy the cab file to a network share
				if($NetworkShareForTestData -ne $Null)
				{
					logDebug("Copy-Item $cabfile $($global:NetworkShareForTestData) -force")
					Copy-Item $cabfile $($global:NetworkShareForTestData) -force
				}
			}
		}
		else
		{
			logInfo("Error: no files in directory: $($global:cabFilesDir)")				
		}
	}
	else
	{
		logInfo("Error: no network path specified")	
		logDebug("Error: could not find path: $($global:NetworkShareForTestData)")
				
	}

}

Function extractCabs()
{
	logDebug("starting function extractCabs")
    $destination = "$($global:extractedLogFilesDir)"
     
    # iterate through all cabs in the directory and extract them
    # cabfiles
    # cabcontents
    
    # Clean out destination directory
    $testfileexists = Test-Path "$destination"
    if($testfileexists)
    {
        $newdir = rd "$destination" -recurse -force
        $newdir = md "$destination"
    }
    if(!$testfileexists)
    {
        $newdir = md "$destination"
    }
    
    $comObject = "Shell.Application"
    Write-Debug "Creating $comObject"
    $shell = New-Object -Comobject $comObject
    logInfo("cabfilesDir=$($global:cabFilesDir)")
	if(Test-Path "$($global:cabFilesDir)")
	{
			
		
		
		$fileEntries = [IO.Directory]::GetFiles("$($global:cabFilesDir)"); 
		foreach($cabfile in $fileEntries) 
		{ 
				logInfo("cabfile:$cabfile")
				if(!$?) { $(Throw "unable to create $comObject object")}
				Write-Debug "Creating source cab object for $cabfile"
				$sourceCab = $shell.Namespace($cabfile).items()
				Write-Debug "Creating destination folder object for $destination"
				$DestinationFolder = $shell.Namespace($destination)
				Write-Debug "Expanding $cabfile to $destination"

				$DestinationFolder.CopyHere($sourceCab)
		}
	}
	else
	{
		logInfo("No test data to analyze"	)
	}
}

function createOneRowForSP2010Report([string]$theRowId)
{
        $temp1kread = $global:a_1k_read["$($theRowId)"] 
        $temp32kread = $global:a_32k_read["$($theRowId)"]
        $temp32kwrite = $global:a_32k_write["$($theRowId)"]
        $temp100mbread = $global:a_100mb_read["$($theRowId)"]
        $temp100mbwrite = $global:a_100mb_write["$($theRowId)"]
        $tempTestfilesize = $global:a_testfilesize["$($theRowId)"]
        $tempTestduration = $global:a_testduration["$($theRowId)"]
        $tempTestserverdisklayout = $global:a_testserverdisklayout["$($theRowId)"]
        $tempTestserverram = $global:a_testserverram["$($theRowId)"]
        
        
        if([int]$temp1kread -gt 2000)
        {
            $color1kread = "green"
        }
        else
        {
            $color1kread = "red"
        }
        if([int]$temp32kread -gt 1800)
        {
            $color32kread = "green"
        }
        else
        {
            $color32kread = "red"
        }
        if([int]$temp32kwrite -gt 900)
        {
            $color32kwrite = "green"
        }
        else
        {
            $color32kwrite = "red"
        }
        if([int]$temp100mbread -gt 500)
        {
            $color100mbread = "green"
        }
        else
        {
            $color100mbread = "red"
        }
        if([int]$temp100mbwrite -gt 250)
        {
            $color100mbwrite = "green"
        }
        else
        {
            $color100mbwrite = "red"
        }
        if($tempTestduration -eq "10 Seconds")
        {      
            $titleTestduration = $global:str_warningMessageForDuration  
            $colorTestduration = "red"
        }
        else
        {
            $titleTestduration = ""  
            $colorTestduration = "white"

        }
        if([String]$tempTestfilesize.Contains("2 GB") -eq $true)
        {        
            $titleTestfilesize = $global:str_warningMessageForFilesize
            $colorTestfilesize = "red"
        }
        else
        {
            $titleTestfilesize = ""
            $colorTestfilesize = "white"

        }
        
        $temprow = @"
<tr>
    <td>$($theRowId)</td> 
    <td style="background-color:$color1kread" align="center">$temp1kread</td>
    <td style="background-color:$color32kread" align="center">$temp32kread</td>
    <td style="background-color:$color32kwrite" align="center">$temp32kwrite</td>
    <td style="background-color:$color100mbread" align="center">$temp100mbread</td>
    <td style="background-color:$color100mbwrite" align="center">$temp100mbwrite</td>
    <td></td>
    <td title="$titleTestfilesize" style="background-color:$colorTestfilesize" align="center">$tempTestfilesize</td>
    <td title="$titleTestduration" style="background-color:$colorTestduration" align="center">$tempTestduration</td>
    <td>$tempTestserverram </td>
    <td>$tempTestserverdisklayout </td>

</tr> 
"@

   return $temprow
}


################
##
##
##
function GenerateReportFor4S4SP2010()
{
	logDebug("starting function GenerateReportFor4S4SP2010")
    $rowresults = ""

    $global:sp2010serverList = $global:sp2010serverList | Sort-Object -Descending

    if($global:sp2010serverList.length -eq 0)
    {
		logDebug("There is no data for an SP2010 report")
        return
    }
    if($global:sp2010serverList[0].Length -eq 1) 
    {
        $rowresults = createOneRowForSP2010Report($($global:sp2010serverList))
    }
    else
    {
    
        $global:sp2010serverList.GetEnumerator() | Foreach-Object {    
            $temprow = createOneRowForSP2010Report($_)
            $rowresults += $temprow
        }
    }

    
#$reportresults = @"
#<tr><td>localhost</td> <td style="background-color:green" align="center">$global:a_1k_read</td><td style="background-color:green" align="center">$global:a_32k_read</td><td style="background-color:green" align="center">$global:a_32k_write</td> <td style="background-color:green" align="center">$global:a_100mb_read</td><td style="background-color:green" align="center">$global:a_100mb_write</td></tr> 
#"@

logInfo("Writing file SP2010 report.html" )
$reporthtml = @"  
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">  
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 

<!-- Report Header -->
<title>Search Benchmark Report: FAST Search for SharePoint 2010</title> </head> 
<body> <h3>Search Benchmark Report: FAST Search for SharePoint 2010</h3>  

<!-- Table definition -->
<table border="1" cellpadding="4" > <colgroup> <col/> <col/> <col/> <col/> <col/> <col/> </colgroup> 

<!-- Header Row -->
<tr>
<th>Environment</th><th>1 KB<br>read<br>[IOPS]</th><th>32 KB<br>read<br>[IOPS]</th><th>32 KB<br>write<br>[IOPS]</th><th>100 MB<br>read<br>[MB/s]</th><th>100 MB<br>write<br>[MB/s]</th>
<th>&nbsp;&nbsp;</th><th>Test File Size</th><th>Test Duration</th><th>RAM</th><th>Disk layout: size/free for each drive</th>

</tr>  

<!-- Row data -->
<tr><td><i>Recommended minimum</i></td><td align="center">2,000</td><td align="center">1,800</td><td align="center">900</td> <td align="center">500</td><td align="center">250</td>
<td></td><td></td><td></td><td></td><td></td>

</tr>
$rowresults
</table> 
<h2>Guidance</h2>
$global:str_reportGuidanceSection 
</body></html> 
"@ | Out-File "SP2010report.html" 

}


function createOneRowForSP2013Report([string]$theRowId)
{
    
        $temp64kread = $global:a_64k_read["$($theRowId)"] 
        $temp256kwrite = $global:a_256k_write["$($theRowId)"]
        $temp100mbread = $global:a_100mb_read["$($theRowId)"]
        $temp100mbwrite = $global:a_100mb_write["$($theRowId)"]
        $tempTestfilesize = $global:a_testfilesize["$($theRowId)"]
        $tempTestduration = $global:a_testduration["$($theRowId)"]
        $tempTestserverdisklayout = $global:a_testserverdisklayout["$($theRowId)"]
        $tempTestserverram = $global:a_testserverram["$($theRowId)"]
        
        if([int]$temp64kread -gt 300)
        {
            $color64kread = "green"
        }
        else
        {
            $color64kread = "red"
        }
        if([int]$temp256kwrite -gt 100)
        {
            $color256kwrite = "green"
        }
        else
        {
            $color256kwrite = "red"
        }
        if([int]$temp100mbread -gt 200)
        {
            $color100mbread = "green"
        }
        else
        {
            $color100mbread = "red"
        }
        if([int]$temp100mbwrite -gt 200)
        {
            $color100mbwrite = "green"
        }
        else
        {
            $color100mbwrite = "red"
        }
        if($tempTestduration -eq "10 Seconds")
        {        
            $titleTestduration = $global:str_warningMessageForDuration  
            $colorTestduration = "red"
        }
        else
        {
            $titleTestduration = ""
            $colorTestduration = "white"

        }
        if([String]$tempTestfilesize.Contains("2 GB") -eq $true)
        {        
            $titleTestfilesize = $global:str_warningMessageForFilesize
            $colorTestfilesize = "red"
        }
        else
        {
            $titleTestfilesize = ""
            $colorTestfilesize = "white"

        }
        
        $temprow = @"
<tr>
    <td>$($theRowId)</td> 
    <td style="background-color:$color64kread" align="center">$temp64kread</td>
    <td style="background-color:$color256kwrite" align="center">$temp256kwrite</td>
    <td style="background-color:$color100mbread" align="center">$temp100mbread</td>
    <td style="background-color:$color100mbwrite" align="center">$temp100mbwrite</td>
    <td></td>
    <td title="$titleTestfilesize" style="background-color:$colorTestfilesize" align="center">$tempTestfilesize</td>
    <td title="$titleTestduration" style="background-color:$colorTestduration" align="center">$tempTestduration</td>
    <td>$tempTestserverram </td>
    <td>$tempTestserverdisklayout </td>
</tr> 
"@


    return $temprow
}

#########################
##
##
## 64KB read IOPS ~ 300
## 256KB write IOPS ~ 100
## 100MB read ~ 200 MB/s
## 100MB write ~ 200 MB/s

function GenerateReportForSP2013()
{
	logDebug("starting function GenerateReportForSP2013")
    $rowresults = ""

    $global:sp2013serverList = $global:sp2013serverList | Sort-Object -Descending

    if($global:sp2013serverList.length -eq 0)
    {
		logDebug("There is no data for an SP2013 report")
        return
    }
    if($global:sp2013serverList[0].Length -eq 1) 
    {
        $rowresults = createOneRowForSP2013Report($($global:sp2013serverList))
    }
    else
    {
    
        $global:sp2013serverList.GetEnumerator() | Foreach-Object {    
            $temprow = createOneRowForSP2013Report($_)
            $rowresults += $temprow
        }
    }
#$reportresults = @"
#<tr><td>localhost</td> <td style="background-color:green" align="center">$global:a_1k_read</td><td style="background-color:green" align="center">$global:a_32k_read</td><td style="background-color:green" align="center">$global:a_32k_write</td> <td style="background-color:green" align="center">$global:a_100mb_read</td><td style="background-color:green" align="center">$global:a_100mb_write</td></tr> 
#"@

logInfo("Writing file $($PWD)\SP2013report.html" )
$reporthtml = @"  
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">  
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 

<!-- Report Header -->
<title>Search Benchmark Report: SharePoint 2013</title> </head> 
<body> <h3>Search Benchmark Report: SharePoint 2013</h3>  

<!-- Table definition -->
<table border="1" cellpadding="4" > <colgroup> <col/> <col/> <col/> <col/> <col/> <col/> </colgroup> 

<!-- Header Row -->
<tr>
<th>Environment</th><th>64 KB<br>read<br>[IOPS]</th><th>256 KB<br>write<br>[IOPS]</th><th>100 MB<br>read<br>[MB/s]</th><th>100 MB<br>write<br>[MB/s]</th>
<th>&nbsp;&nbsp;</th><th>Test File Size</th><th>Test Duration</th><th>RAM</th><th>Disk layout: size/free for each drive</th>
</tr>  

<!-- Row data -->
<tr><td><i>Recommended minimum</i></td><td align="center">300</td><td align="center">100</td> <td align="center">200</td><td align="center">200</td>
<td></td><td></td><td></td><td></td><td></td>
</tr>
$rowresults
</table> 
<h2>Guidance</h2>
$global:str_reportGuidanceSection 
</body></html> 
 
"@ | Out-File "SP2013report.html" 

}

######################
##
##
##
function getNum([string] $line)
{
   $pieces = $line.split(":") 
   $thenum = [int]$pieces[1]
   $returnme = "{0:N0}" -f $thenum
   return $returnme
}

######################
##
##
##
function getRunDetails([string] $line)
{
   $pieces = $line.split("|") 
   $returnme = $pieces[1]
   return $returnme
}

######################
## 
## Create the test file 
##
function initializeTestfile()
{
	logDebug("starting function initializeTestfile")
    $datfile = "$($global:drivePathToTest)\testfile.dat"
    $testfileexists = Test-Path "$datfile"
    if(!$testfileexists -or !$global:KeepTestFile)
    {
        if($testfileexists) 
		{ 
			logInfo("Cleaning up old test file $datfile")
			Remove-Item "$datfile" 
		}
        cd sqlio
        logInfo("Creating new test file($datfile) based on settings in file:$($pwd)\param. Use flag -KeepTestFile to preserve prior file")
        .\sqlio -kW -s10 -fsequential -t8 -o8 -b8 -LS -F"param" timeout /T 10 > temp.txt
        cd ..
        
    }
    $testfileexists = Test-Path "$datfile"
    if($testfileexists)
    {
        $fileobj = Get-Item "$datfile"
        [int]$filesize = $fileobj.length/1GB
        $global:TestFileSize = $filesize
        write-host "Using test file: $datfile of size: $filesize GB. To change the drive, use the parameter DrivePathToTest. i.e. -DrivePathToTest c:\sqliotesting" -Foregroundcolor yellow
    }
    else
    {
        logInfo("There was an error creating the test file")
        exit
    }
}



Function New-DDF($cabFilePath,$filesToAddPath)
{
	logDebug("starting function New-DDF")

    $ddfFile = Join-Path -path $cabFilePath -childpath temp.ddf
 
    if($global:Verbose) { "Creating new cabfile $cabFilePath\$($global:servername)-sqliologs.cab"}
    $ddfHeader =@"
;*** MakeCAB Directive file
;
.OPTION EXPLICIT      
.Set CabinetNameTemplate=$($global:servername)-sqliologs.cab
.set DiskDirectory1=$cabFilePath
.Set MaxDiskSize=CDROM
.Set Cabinet=on
.Set Compress=on
"@
 
    Write-Debug "Writing ddf file header to $ddfFile" 
    $ddfHeader | Out-File -filepath $ddfFile -force -encoding ASCII
    Write-Debug "Generating collection of files from $filesToAddPath"
    Get-ChildItem -path $filesToAddPath | 
    Where-Object { !$_.psiscontainer } |
    ForEach-Object `
    { 
        '"' + $_.fullname.tostring() + '"' | 
        Out-File -filepath $ddfFile -encoding ASCII -append
    }
    Write-Debug "ddf file is created. Calling New-Cab function"
    New-Cab($ddfFile) 

    if($global:Verbose) { "Done creating cabfile $cabFilePath\$($global:servername)-sqliologs.cab" }

} #end New-DDF

Function New-Cab($ddfFile)
{
	logDebug("starting function New-Cab")
    Write-Debug "Entering the New-Cab function. The DDF File is $ddfFile"
    if($global:Verbose) 
    { 
        $cabresults = makecab /f $ddfFile /V3 
    }
    Else
    { 
        $cabresults = makecab /f $ddfFile 
    } 
 
    rm $ddfFile
    rm "setup.inf"
    rm "setup.rpt"

} #end New-Cab

function parseLogsFor4S4SP2010()
{   
	logDebug("starting function parseLogsFor4S4SP2010")
    # get a list of the servers to review
    gci "$($global:extractedLogFilesDir)" | % `
    {
        $theFile = $_.BaseName
        $splitPos = $theFile.IndexOf('_2010_')
        if ($splitPos -gt 0)
        {
            $serverName = $theFile.substring(0,$splitPos)
            #$global:sp2010serverList["$serverName"]=$serverName
            if ( $global:sp2010serverList -notcontains $serverName)
            {
                $global:sp2010serverList += $serverName
            }
        }
    }
    $global:sp2010serverList.GetEnumerator() | Foreach-Object {        

        $temp_a_1k_read     = gc "$($global:extractedLogFilesDir)\$($_)_2010_1kread.txt" | select-string 'Ios/sec' 
        $temp_a_32k_read    = gc "$($global:extractedLogFilesDir)\$($_)_2010_32kread.txt" | select-string 'Ios/sec' 
        $temp_a_32k_write   = gc "$($global:extractedLogFilesDir)\$($_)_2010_32kwrite.txt" | select-string 'Ios/sec' 
        $temp_a_100mb_read  = gc "$($global:extractedLogFilesDir)\$($_)_2010_100mbread.txt" | select-string 'MBs/sec' 
        $temp_a_100mb_write = gc "$($global:extractedLogFilesDir)\$($_)_2010_100mbwrite.txt" | select-string 'MBs/sec' 
        [string]$temp_testfilesize  = gc "$($global:extractedLogFilesDir)\$($_)_2010_rundetails.txt" | select-string 'TestFileSize' 
        [string]$temp_testduration  = gc "$($global:extractedLogFilesDir)\$($_)_2010_rundetails.txt" | select-string 'TestDuration' 
        [string]$temp_testserverdisklayout  = gc "$($global:extractedLogFilesDir)\$($_)_2010_rundetails.txt" | select-string 'TestServerDiskLayout' 
        [string]$temp_testserverram  = gc "$($global:extractedLogFilesDir)\$($_)_2010_rundetails.txt" | select-string 'TestServerRam' 

        $global:a_1k_read["$($_)"] = getNum $temp_a_1k_read 
        $global:a_32k_read["$($_)"] = getNum $temp_a_32k_read
        $global:a_32k_write["$($_)"] = getNum $temp_a_32k_write
        $global:a_100mb_read["$($_)"] = getNum $temp_a_100mb_read 
        $global:a_100mb_write["$($_)"] = getNum $temp_a_100mb_write 

        $global:a_testfilesize["$($_)"] = getRunDetails $temp_testfilesize 
        $global:a_testduration["$($_)"] = getRunDetails $temp_testduration 
        $global:a_testserverdisklayout["$($_)"] = getRunDetails $temp_testserverdisklayout 
        $global:a_testserverram["$($_)"] = getRunDetails $temp_testserverram 

    }
}

function parseLogsForSP2013()
{   
	logDebug("starting function parseLogsForSP2013")
    #"Starting parseLogsForSP2013"
    # get a list of the servers to review
    gci "$($global:extractedLogFilesDir)" | % `
    {
        $theFile = $_.BaseName
        $splitPos = $theFile.IndexOf('_2013_')
        if ($splitPos -gt 0)
        {
            $serverName = $theFile.substring(0,$splitPos)
            if ( $global:sp2013serverList -notcontains $serverName)
            {
                $global:sp2013serverList += $serverName
            }
        }
    }
    $global:sp2013serverList.GetEnumerator() | Foreach-Object {        
        
        $temp_a_64k_read = gc "$($global:extractedLogFilesDir)\$($_)_2013_64kread.txt" | select-string 'Ios/sec' 
        $temp_a_256k_write = gc "$($global:extractedLogFilesDir)\$($_)_2013_256kwrite.txt" | select-string 'Ios/sec' 
        $temp_a_100mb_read = gc "$($global:extractedLogFilesDir)\$($_)_2013_100mbread.txt" | select-string 'MBs/sec' 
        $temp_a_100mb_write = gc "$($global:extractedLogFilesDir)\$($_)_2013_100mbwrite.txt" | select-string 'MBs/sec' 

        [string]$temp_testfilesize  = gc "$($global:extractedLogFilesDir)\$($_)_2013_rundetails.txt" | select-string 'TestFileSize' 
        [string]$temp_testduration  = gc "$($global:extractedLogFilesDir)\$($_)_2013_rundetails.txt" | select-string 'TestDuration' 
        [string]$temp_testserverdisklayout  = gc "$($global:extractedLogFilesDir)\$($_)_2013_rundetails.txt" | select-string 'TestServerDiskLayout' 
        [string]$temp_testserverram  = gc "$($global:extractedLogFilesDir)\$($_)_2013_rundetails.txt" | select-string 'TestServerRam' 
   
        $global:a_64k_read["$($_)"] = getNum $temp_a_64k_read 
        $global:a_256k_write["$($_)"] = getNum $temp_a_256k_write
        $global:a_100mb_read["$($_)"] = getNum $temp_a_100mb_read 
        $global:a_100mb_write["$($_)"] = getNum $temp_a_100mb_write 

        $global:a_testfilesize["$($_)"] = getRunDetails $temp_testfilesize 
        $global:a_testduration["$($_)"] = getRunDetails $temp_testduration 
        $global:a_testserverdisklayout["$($_)"] = getRunDetails $temp_testserverdisklayout 
        $global:a_testserverram["$($_)"] = getRunDetails $temp_testserverram 
    }
    #$global:sp2013serverList
}

#####################
##
##
##
function startTestsFor4S4SP2010()
{
	logDebug("starting function startTestsFor4S4SP2010")
    $seconds = "-s$($global:TestDurationInSeconds)"
    $iopath = $global:drivePathToTest
    
    
    $testfileexists = Test-Path "$global:templogfiles"
    if(!$testfileexists)
    {
        $res = md "$global:templogfiles"
    }
    
    logInfo(" Running 1KB Read")
    $thecommand = @"
    .\sqlio\sqlio.exe -kR -t4 -o25 -b1 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_1kread.txt"
"@
    if($global:Verbose) { $thecommand }
    .\sqlio\sqlio.exe -kR -t4 -o25 -b1 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_1kread.txt"

    logInfo(" Running 32KB Read") #"
    $thecommand = @"
    .\sqlio\sqlio.exe -kR -t4 -o25 -b32 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_32kread.txt"
"@
    if($global:Verbose) { $thecommand }
    .\sqlio\sqlio.exe -kR -t4 -o25 -b32 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_32kread.txt"


    logInfo(" Running 32KB Write") #"
    $thecommand = @"
    .\sqlio\sqlio.exe -kW -t4 -o25 -b32 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_32kwrite.txt"
"@
    if($global:Verbose) { $thecommand }
    .\sqlio\sqlio.exe -kW -t4 -o25 -b32 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_32kwrite.txt"


    logInfo(" Running 100MB Read") #"
    $thecommand = @"
    .\sqlio\sqlio.exe -kR -t1 -o1 -b100000 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_100mbread.txt"
"@
    if($global:Verbose) { $thecommand }
    .\sqlio\sqlio.exe -kR -t1 -o1 -b100000 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_100mbread.txt"


    logInfo(" Running 100MB Write") #"
    $thecommand = @"
    .\sqlio\sqlio.exe -kW -t1 -o1 -b100000 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_100mbwrite.txt"
"@
    if($global:Verbose) { $thecommand }
    .\sqlio\sqlio.exe -kW -t1 -o1 -b100000 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2010_100mbwrite.txt"

    logInfo("Creating run details file")
    "TestFileSize|$($global:drivePathToTest) <br>$($global:TestFileSize) GB" > "$($global:templogfiles)\$($global:servername)_2010_rundetails.txt"

    $tempRam = (get-wmiobject Win32_PhysicalMemory| Measure-Object -Property Capacity -Sum).Sum/1gb
    "TestServerRam|$tempRam GB" >> "$($global:templogfiles)\$($global:servername)_2010_rundetails.txt"
    "TestDuration|$($global:TestDurationInSeconds) Seconds" >> "$($global:templogfiles)\$($global:servername)_2010_rundetails.txt"

    $disks = Get-WmiObject -ComputerName $($env:computername) -Class Win32_LogicalDisk -Filter "DriveType = 3";
 
    $tempdiskstr = ""
	foreach($disk in $disks)
	{
		$deviceID = $disk.DeviceID;
		[float]$size = $disk.Size;
		[float]$freespace = $disk.FreeSpace;
 
		$percentFree = [Math]::Round(($freespace / $size) * 100, 2);
		$sizeGB = [Math]::Round($size / 1073741824, 2);
		$freeSpaceGB = [Math]::Round($freespace / 1073741824, 2);
 
        $tempdiskstr += "$deviceID size:$sizeGB GB free:$freeSpaceGB GB %free:$percentFree <br>"
		#Write-Host -ForegroundColor $colour "$server $deviceID percentage free space = $percentFree";
		#Add-Content "$Env:USERPROFILE\server disks $datetime.txt" "$server,$deviceID,$sizeGB,$freeSpaceGB,$percentFree";
        
	}

    "TestServerDiskLayout|$tempdiskstr " >> "$($global:templogfiles)\$($global:servername)_2010_rundetails.txt"

}


##################
##
##
## 64KB read IOPS ~ 300
## 256KB write IOPS ~ 100
## 100MB read ~ 200 MB/s
## 100MB write ~ 200 MB/s
##
function startTestsForSP2013()
{
	logDebug("starting function startTestsForSP2013")
    $seconds = "-s$($global:TestDurationInSeconds)"
    $iopath = $global:drivePathToTest
    
    
    $testfileexists = Test-Path "$global:templogfiles"
    if(!$testfileexists)
    {
        $res = md "$global:templogfiles"
    }
    
    logInfo(" Running 64KB Read")
    $thecommand = @"
    .\sqlio\sqlio.exe -kR -t4 -o25 -b64 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2013_64kread.txt"
"@
    if($global:Verbose) { $thecommand }
    .\sqlio\sqlio.exe -kR -t4 -o25 -b64 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2013_64kread.txt"

    logInfo(" Running 256KB Write") #"
    $thecommand = @"
    .\sqlio\sqlio.exe -kW -t4 -o25 -b256 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2013_256kwrite.txt"
"@
    if($global:Verbose) { $thecommand }
    .\sqlio\sqlio.exe -kW -t4 -o25 -b256 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2013_256kwrite.txt"
    
    logInfo(" Running 100MB Read") #"
    $thecommand = @"
    .\sqlio\sqlio.exe -kR -t1 -o1 -b100000 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2013_100mbread.txt"
"@
    if($global:Verbose) { $thecommand }
    .\sqlio\sqlio.exe -kR -t1 -o1 -b100000 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2013_100mbread.txt"
    
    logInfo(" Running 100MB Write") #"
    $thecommand = @"
    .\sqlio\sqlio.exe -kW -t1 -o1 -b100000 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2013_100mbwrite.txt"
"@
    if($global:Verbose) { $thecommand }
    .\sqlio\sqlio.exe -kW -t1 -o1 -b100000 -frandom $seconds -LS -BN "$iopath\testfile.dat" > "$($global:templogfiles)\$($global:servername)_2013_100mbwrite.txt"

    logInfo("Creating run details file")
    "TestFileSize|$($global:drivePathToTest) <br>$($global:TestFileSize) GB" > "$($global:templogfiles)\$($global:servername)_2013_rundetails.txt"
    $tempRam = (get-wmiobject Win32_PhysicalMemory| Measure-Object -Property Capacity -Sum).Sum/1gb
    "TestServerRam|$tempRam GB" >> "$($global:templogfiles)\$($global:servername)_2013_rundetails.txt"
    "TestDuration|$($global:TestDurationInSeconds) Seconds" >> "$($global:templogfiles)\$($global:servername)_2013_rundetails.txt"
    $disks = Get-WmiObject -ComputerName $($env:computername) -Class Win32_LogicalDisk -Filter "DriveType = 3";
  
    $tempdiskstr = ""
	foreach($disk in $disks)
	{
		$deviceID = $disk.DeviceID;
		[float]$size = $disk.Size;
		[float]$freespace = $disk.FreeSpace;
 
		$percentFree = [Math]::Round(($freespace / $size) * 100, 2);
		$sizeGB = [Math]::Round($size / 1073741824, 2);
		$freeSpaceGB = [Math]::Round($freespace / 1073741824, 2);
 
        $tempdiskstr += "$deviceID size:$sizeGB GB free:$freeSpaceGB GB %free:$percentFree <br>"
		#Write-Host -ForegroundColor $colour "$server $deviceID percentage free space = $percentFree";
		#Add-Content "$Env:USERPROFILE\server disks $datetime.txt" "$server,$deviceID,$sizeGB,$freeSpaceGB,$percentFree";
        
	}

    "TestServerDiskLayout|$tempdiskstr " >> "$($global:templogfiles)\$($global:servername)_2013_rundetails.txt"
}


#####################
##
##
##
function testit()
{
	logDebug("starting function testit")
    $global:servername = "test1"
    mainwork
    $global:servername = "test2"
    mainwork
    $global:servername = "test3"
    mainwork
    $global:servername = "test_4"
    mainwork


}

function generateReports()
{
	logDebug("starting function generateReports")
    
	extractCabs

    parseLogsFor4S4SP2010
    GenerateReportFor4S4SP2010

    parseLogsForSP2013
    GenerateReportForSP2013
	
	cleanLogs

    if($global:sp2010serverList.length -gt 0)
    {
        ./SP2010report.html
    }

    Sleep 1

    if($global:sp2013serverList.length -gt 0)
    {
        ./SP2013report.html
    }

}

function DisplayGlobalVariables()
{

	logDebug("Using following program variable settings: ")
	"`tCleanup:$($global:Cleanup)  "
	"`tDatFileSize:$($global:DatFileSize) "
	"`tKeepTestFile:$($global:KeepTestFile) "
	"`tOnlyGenerateReports:$($global:OnlyGenerateReports) "
	"`tTestDurationInSeconds:$($global:TestDurationInSeconds) "
	"`tNetworkShareForTestData:$($global:NetworkShareForTestData) "
	"`tdrivePathToTest:$($global:drivePathToTest) "
	"`ttemplogfiles:$($global:templogfiles) "
	"`tVerbose:$($global:Verbose) "
	"`textractedLogFilesDir:$($global:extractedLogFilesDir) "
	"`tcabFilesDir:$($global:cabFilesDir) "
	"`tSP2010:$($global:SP2010)  "
	"`tSP2013:$($global:SP2013) "

}

Function MExec {
    Param ([string] $ServerFile = 'servers.txt', [string] $ScriptFile = 'hostname.ps1', [Object[]] $ArgumentList = @(), [boolean] $Sequential = $false)

    # If this fails the script should not run, so don't catch any errors.
    $servers = (Get-Content $ServerFile | where {$_ -ne ""})
    #$ArgumentList
    # Grab STDIN
    [string[]] $commands = @()
	$charhash = [char]35
	$strmultiline = "THISISAMULTILINE" + "COMMENT"
	$input | foreach { $commands1 += ($_ -replace "\s*$($charhash)>.*", "`n$($strmultiline)>")}
	$commands1 | foreach { $commands2 += ($_ -replace "\s*<$($charhash).*", "`n<$($strmultiline)")}
	$commands2 | foreach { $commands3 += ($_ -replace "\s*$($charhash).*", '')}
	$commandCount = $commands3.Length
    if ($commandCount -gt 0) {
		$endstr = "END" + "REMOVE"
		$beginstr = "BEGIN" + "REMOVE"
        $commandStr = [string]::join("; ", $commands3)
		$commandStr = ($commandStr -replace "(?s)$($beginstr).*?$($endstr)", "") 
		$commandStr = ($commandStr -replace "(?s)<$($strmultiline).*?$($strmultiline)>", "") 
	    $commandBlock = [scriptblock]::Create($commandStr)
	    if ($commandCount -gt 5) {

            Write-Host "Running $commandCount commands on the following servers: $servers"
        }
        else {
			if($commandStr.Length -lt 200){
			    Write-Host "Running command '$commandStr' on the following servers: $servers"
			}
			else {
			    Write-Host "Running of length $($commandStr.Length) on the following servers: $servers"			
			}

        }
        if ($Sequential -eq $true) {
            $result = @()
            foreach ($server in $servers) {
                $result += Invoke-Command -ComputerName $server -ScriptBlock $commandBlock -ArgumentList $ArgumentList
            }
            return $result
        }
        else {
            return Invoke-Command -ComputerName $servers -ScriptBlock $commandBlock -ArgumentList $ArgumentList
        }
    }
    else {
        Write-Host "Running script '$($ScriptFile)' on the following servers: $servers"
		$ArgumentList
        if ($Sequential -eq $true) {
            $result = @()
            foreach ($server in $servers) {
                $result += Invoke-Command -ComputerName $server -FilePath $ScriptFile -ArgumentList $ArgumentList
            }
            return $result
        }
        else {
            return Invoke-Command -ComputerName $servers -FilePath $ScriptFile -ArgumentList $ArgumentList
        }
    }

}

function createshare($Foldername, $Sharename)
{
    # Test for existence of folder, if not there then create it 
    # 
    IF (!(TEST-PATH $Foldername)) 
	{ 
		NEW-ITEM $Foldername -type Directory 
	} 

	# Create Share but check to make sure it isn�t already there 
	# 

	$fullaccessusers = $env:USERDNSDOMAIN+"\"+$env:USERNAME
	$fullaccessusers = "Everyone"
		
	if (!(gwmi Win32_Share -filter "name='$Sharename'")) 
	{	
		#New-SMBShare is not available on all OS versions
		New-SMBShare -Name $Sharename -Path $Foldername -FullAccess "$fullaccessusers"
	} 
}

# todo these two remote methods can probably be removed if we pass in all the parameters to the main remote call
function remoteCleanupOldTestData()
{
	#$psfile = Get-Content .\SearchBenchmarkWithSQLIO.ps1 -delimiter ([char]0) 
	#$psfile = ($psfile -replace "(?s)<#.*?#>", "") 
		
    #$script = [scriptblock]::create( "param(`$OnlyCleanupOldTestData) &{ $($psfile) } @PSBoundParameters" )
    
	$script = [scriptblock]::create( "param(`$OnlyCleanupOldTestData) &{ $(Get-Content .\SearchBenchmarkWithSQLIO.ps1 -delimiter ([char]0)) } @PSBoundParameters" )
    $script | MExec $global:serverFile -ArgumentList $global:OnlyCleanupOldTestData
}

function remoteCollectTestData([String]$NetworkShareForTestData)
{
    $script = [scriptblock]::create( "param(`$OnlyCollectTestData,`$NetworkShareForTestData) &{ $(Get-Content .\SearchBenchmarkWithSQLIO.ps1 -delimiter ([char]0)) } @PSBoundParameters" )
    $script | MExec $global:serverFile -ArgumentList $global:OnlyCollectTestData,$NetworkShareForTestData
}

function remotecontrolmain()
{    
	$localdirForTestData = Join-Path ($ENV:HOMEDRIVE+ $ENV:HOMEPATH + "\Documents")  "SqlioData"
    $NetworkShareForTestData = "\\"+$ENV:Computername+"\SqlioData"
	
	if($global:Cleanup)
	{
		remoteCleanupOldTestData
		del "$($localdirForTestData)\*"
		return
	}

	# Create a Share for cab files
	createshare $localdirForTestData "SqlioData"
	
	# instruct all servers to copy their test data to the network share 
	# TODO: This may fail for some psexec reason. If the fileshare copy fails, then create a bat file and pull all cabs from the remote locations
	# 		The bat should be easy to generate. All servers are listed in servers.txt. The homedrive,homepath should be the same on all servers since the same user is running the tests 
	<#
    if($OnlyCollectTestData)
	{
		remoteCollectTestData -NetworkShareForTestData $NetworkShareForTestData
		return
	}	
		
	if($OnlyGenerateReports)
	{
		.\SearchBenchmarkWithSQLIO.ps1 -OnlyGenerateReports -cabFilesDir $NetworkShareForTestData
		return
	}
	#>

    $allowedFileSizes = "2GB", "20GB", "250GB"
    if (-not ($allowedFileSizes -contains $global:DatFileSize)) {
        Write-Warning "When this script was written, the SQLIO test script only supported file sizes of 2GB, 20GB, or 250GB."
    }

	$script = [scriptblock]::create( "param(`$DrivePathToTest,`$TestDurationInSeconds,`$DatFileSize,`$Verbose,`$NetworkShareForTestData,`$KeepTestFile) &{ $(Get-Content .\SearchBenchmarkWithSQLIO.ps1 -delimiter ([char]0)) } @PSBoundParameters" )
    $script | MExec $global:serverFile -ArgumentList $global:DrivePathToTest,$global:TestDurationInSeconds,$global:DatFileSize,$global:Verbose,$NetworkShareForTestData,$global:KeepTestFile
	

    # TODO create a remove/cleanup method and only remove when the cleanup is called.
    #"Remove-Item F:\testfile.dat" | MExec "servers.txt"
		
	#.\SearchBenchmarkWithSQLIO.ps1 -OnlyGenerateReports -cabFilesDir $NetworkShareForTestData
}


##########################################
##
## Main program execution
##
##########################################

function main()
{
	if($global:debug)
	{
		DisplayGlobalVariables
	}
	
	if($global:runRemote)
	{
		remotecontrolmain
        # Copy the test files locally
        Write-host "Copy the cabfiles locally"
        $servers = (Get-Content $global:serverFile | where {$_ -ne ""})
        foreach ($server in $servers) {
            Write-Host "copy \\$server\C$\Users\$($env:USERNAME)\Documents\cabfiles $pwd -Recurse -force"
            copy \\$server\C$\Users\$($env:USERNAME)\Documents\cabfiles $pwd -Recurse -force
        }
        generateReports
		return
	}
    
    if($global:deletecabFiles) {
        # delete cabfiles from servers
        $servers = (Get-Content $global:serverFile | where {$_ -ne ""})
        del $pwd\cabfiles\*.* -force
        foreach ($server in $servers) {
            del \\$server\C$\Users\$($env:USERNAME)\Documents\cabfiles\*.* -force
        }
        return
    }

	if($global:OnlyCollectTestData)
	{
        # Copy the test files locally
        Write-host "Copy the cabfiles locally"
        $servers = (Get-Content $global:serverFile | where {$_ -ne ""})
        foreach ($server in $servers) {
            Write-Host "copy \\$server\C$\Users\$($env:USERNAME)\Documents\cabfiles $pwd -Recurse -force"
            copy \\$server\C$\Users\$($env:USERNAME)\Documents\cabfiles $pwd -Recurse -force
        }
        #pushCabFilesToNetworkShare
		return
	}
	
    if($global:OnlyGenerateReports)
    {
        generateReports
        return
    }
	
	if($global:OnlyCleanupOldTestData)
    {
        cleanup
        return
    }
	
	#TODO
	# Display a message if the duration is more than 60 seconds. Verify they are ready to run a long test.
	if($global:TestDurationInSeconds -gt 60)
	{


	}

    downloadAndInstallSQLIO

    createParamFiles
    
    ChooseParamFile

    cleanLogs

    initializeTestfile

    if($global:SP2010)
    {
        startTestsFor4S4SP2010
    }

    if($global:SP2013)
    {
        startTestsForSP2013
    }

    createCabFile
    	
    generateReports
    
    DisplayUserFeedback
    
}

main





# SIG # Begin signature block
# MIIkwQYJKoZIhvcNAQcCoIIksjCCJK4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB/bK1ZDpwjU4Cn
# Y3ySyULA7sVryt1c7bXjQC96hMTayaCCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWljCCFpICAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCCAWkwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPBvPAA9
# TIAbo5q+HUo9lCXu7ncJY0b4JZYe4S58geXMMIH8BgorBgEEAYI3AgEMMYHtMIHq
# oFaAVABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBs
# AHQAaAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKGBj4CBjGh0
# dHBzOi8vYmxvZ3MubXNkbi5taWNyb3NvZnQuY29tL3NoYXJlcG9pbnRfc3RyYXRl
# Z2VyeS8yMDE2LzAyLzAxL2Fubm91bmNpbmctdGhlLXNlYXJjaC1oZWFsdGgtcmVw
# b3J0cy1zcngtZm9yLXNoYXJlcG9pbnQtc2VhcmNoLWRpYWdub3N0aWNzMA0GCSqG
# SIb3DQEBAQUABIIBAKyBEQS9hVGRRmNjz11EeiWqEmBHisMoVReIU0xkqJxPfsDu
# AZ68huHAGhIw1Ae/KlhiybRN3rViqRs0WGyYBvkqlVWYPJwTE3hUrieMdgJiOI7v
# i6DIG+YLgtUup+2+/r+diYhso/rtrY3Did+I1tE4hu4LhyqyUtE01MOxVZaEvqlU
# zQubJT9LxjW8gY47U1iPxoqLhCGeYvKbX5MFhy5SjutHwZNXTSVEHfvslOztFzxD
# j1PzPuoHmmy1Fgb5zkFIVSrPejgA8uUtRZ34irXw0cyhQuMycEwsebxEYtIk2kTG
# Mo2vntqgi5SiUlCIwPXFlMnscqD1S0BXbXQshpKhghNkMIITYAYKKwYBBAGCNwMD
# ATGCE1AwghNMBgkqhkiG9w0BBwKgghM9MIITOQIBAzEPMA0GCWCGSAFlAwQCAQUA
# MIIBPQYLKoZIhvcNAQkQAQSgggEsBIIBKDCCASQCAQEGCisGAQQBhFkKAwEwMTAN
# BglghkgBZQMEAgEFAAQgV7PBiEFDHrBjS5v92niRAC1cF3NQf6HThGMz+iRRsnsC
# Blt11bQj3BgTMjAxODA4MTcyMjA3NTcuNzk2WjAHAgEBgAIB9KCBuaSBtjCBszEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9Q
# UjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNOOjk4RkQtQzYxRS1FNjQxMSUwIwYD
# VQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIOzzCCBNowggPCoAMC
# AQICEzMAAACdIJxWd1XUKJoAAAAAAJ0wDQYJKoZIhvcNAQELBQAwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTYwOTA3MTc1NjQxWhcNMTgwOTA3MTc1
# NjQxWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsG
# A1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNOOjk4RkQtQzYxRS1F
# NjQxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0kSYnBFaKhouqp9TXW1dvLZZdpHA
# JlsD5shsX6Mq60wARnQ4FL8qeF2wI0zsbmBI7EnkW3WmcP3z1K5Vbo69BB9nPRn9
# MXKClKFzsS688BzU2+8huMaptMbCRgcumcw+IQvDLkjfDGp1xTWO11mcqztIfp6y
# 4PxUlt4TRzlC0G7WS/2/DKTwC+X66MiIi+6c+3XhxEvoyw5kzlfeYKh6Ss5lHLhl
# liNiO38FT1lm3ekN1fh8vsBM3nsKlhvMVTkEbwYIQTi79RnftXoEdwUc4uyMx/Gx
# ml5HbsyyHqPalniB7vAHmIBRvroKFB5+njpZJKFXcwz+QUROlsJUUQ+pxQIDAQAB
# o4IBGzCCARcwHQYDVR0OBBYEFLyGCMpbalrK5L3My4K0FUjqh+WhMB8GA1UdIwQY
# MBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6
# Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBD
# QV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# DQYJKoZIhvcNAQELBQADggEBAH/eJCG9We+01otxylmRvi6oRoK7j99kHX3mKgu8
# KGdL/vl3v7X0TqT96EoPPmcis1aJbZcIWuwjFPV5KhNXjJIXnQYh6vOo6hs73NuE
# mkv3chX2n48nqP+l4tYgiZVNQKkVYF65lwHXMAv/QmprVtnsWlw2A4DMFi1qwbkz
# ZE/bXmt/2G/AroGlOO06zl1yGoxMFctfk4yy3aoALeP9ZCipqb4QHf4V3CePH46k
# A+qON9sEJVMf4TJ69zsikMzcKg3BXoYJ1T5W76sloHrLMkBY9r0JW7bJ/3tHeXSG
# pYad2CINV17hqA3GJk4C9v069gGs95e8uZEOYdud0++mNmkwggZxMIIEWaADAgEC
# AgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0
# aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEy
# MTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCC
# hfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRU
# QwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FU
# sc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBX
# day9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4
# HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCC
# AeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2ha
# hW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNV
# HRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYG
# A1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3Js
# L3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcB
# AQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kv
# Y2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUw
# gZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0
# HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0
# AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1
# Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRg
# Eop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X
# 9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbl
# jjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQ
# eKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ou
# OVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+9
# 8eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUB
# HoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ay
# p0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXj
# ad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb
# 01+P3nSISRKhggN4MIICYAIBATCB46GBuaSBtjCBszELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNp
# cGhlciBEU0UgRVNOOjk4RkQtQzYxRS1FNjQxMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBTZXJ2aWNloiUKAQEwCQYFKw4DAhoFAAMVABgNrLOMaDCz+HQZ
# snjOgCs1Lwj6oIHCMIG/pIG8MIG5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMScwJQYDVQQLEx5uQ2lwaGVyIE5UUyBF
# U046NTdGNi1DMUUwLTU1NEMxKzApBgNVBAMTIk1pY3Jvc29mdCBUaW1lIFNvdXJj
# ZSBNYXN0ZXIgQ2xvY2swDQYJKoZIhvcNAQEFBQACBQDfIXzzMCIYDzIwMTgwODE4
# MDA1NzIzWhgPMjAxODA4MTkwMDU3MjNaMHYwPAYKKwYBBAGEWQoEATEuMCwwCgIF
# AN8hfPMCAQAwCQIBAAIBVgIB/zAHAgEAAgIZEDAKAgUA3yLOcwIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMBoAowCAIBAAIDFuNgoQowCAIBAAIDB6Eg
# MA0GCSqGSIb3DQEBBQUAA4IBAQCc4GH1+13CQ6m2iF7EYrYyJpIbK8cE/fMO/axC
# D9EI9BdCx1rYzjdH8mycOnXKh+6LFurVlixg60YJStteFd84Z95YPgcp+0azLGRA
# kAcbX6/sAsOh0AlDlT4VEeMfhcFKW6HAFLYPUY9LixO3VRrAbGfO6C5+2XqkoU2M
# tCv7pbCxvE+35cletBazFeXr+T2wB2hTvGhsPsQAb+YUmnKD476tk+OlHbTnFG1V
# 8EkZhojOJruCv1OLAgWIOkeis1UFPZCuysp1s8WmK+/5MLWyNx15UOAfJe/lBCh6
# LleqlBtmN6gw1NNYH2SB+6fDND1cOPCG07c4qBwnR4neW8B4MYIDDTCCAwkCAQEw
# gZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAACdIJxWd1XUKJoA
# AAAAAJ0wDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAvBgkqhkiG9w0BCQQxIgQgJbiD82h7X5BNa8WCUVs2tWP8UOsSqUGD7z8N
# 1ir7ObowgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCO+T9XlT9vgM/75WQ4
# N7tHSc+8TGVvcOLxWCd9pCapHDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwAhMzAAAAnSCcVndV1CiaAAAAAACdMCIEIDYIIJMfr8RX3BENtWgf
# 3lBFVLVZWgAjwSTmC74+NXpgMA0GCSqGSIb3DQEBCwUABIIBAMY6FnG+kzcka5cr
# jLJgGVZvH5wOp6os9oiN8d9SBk7erPCFomoGWCugFgwcq6oakx4JImLLT2hHojYO
# FMRmf/eb/TqZOOR40eJ48MyF59V2fysjADIkskhbnsHTYPdg2pqObDLR4YZJlRW6
# GrkMfts/Y1ikzuvoU7i+iRcEOOSTVPCFPHDpwhBjFinye4W8xzBe5ZrLhbN6J9wA
# pVekiQynjEUtSbdBTdjP8m9m0KTxNZGvW4zquyU+KSnOJD/Ir9XqUTppWClnsA+R
# r1kkuAM19pDQSobYTJT7IOtl/U5aIxURXmVsFofN4zLm20PQQ+4XYf+Wnmk+ioxG
# vRsrJF4=
# SIG # End signature block
