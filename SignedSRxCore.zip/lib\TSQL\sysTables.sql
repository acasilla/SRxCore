USE [**DBNAME**]; 
SELECT name FROM sys.tables WHERE Type = 'U'
