function Export-SRxToOMS 
{ 
<#
.SYNOPSIS 
	Custom logging module 

.DESCRIPTION
	
.NOTES
	=========================================
	Project		: Search Health Reports (SRx)
	-----------------------------------------
	File Name 	: Export-SRxToOMS.psm1
    Author		: Eric Dixon, Wei Hao Lim
	Requires	: PowerShell Version 3.0, Search Health Reports (SRx)	
	========================================================================================
	This Sample Code is provided for the purpose of illustration only and is not intended to 
	be used in a production environment.  
	
		THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY
		OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
		WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

	We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to 
	reproduce and distribute the object code form of the Sample Code, provided that You agree:
		(i) to not use Our name, logo, or trademarks to market Your software product in 
			which the Sample Code is embedded; 
		(ii) to include a valid copyright notice on Your software product in which the 
			 Sample Code is embedded; 
		and 
		(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against
			  any claims or lawsuits, including attorneys' fees, that arise or result from 
			  the use or distribution of the Sample Code.

	========================================================================================
	
.EXAMPLE
	Write-SRx VERBOSE "some message here..." -ForegroundColor Cyan -NoNewline

#>
[CmdletBinding()]
param ( 
        [parameter(Mandatory=$true,ValueFromPipeline=$true)]
		[object[]]$data,
		[switch]$PassThru=$true
    )

	BEGIN 
    {
 		Write-SRx DEBUG "BEGIN"
		if(-not $global:SRxEnv.OMS.Initialized)
		{
			$errMsg = "Unable to export data. The `$SRxEnv.OMS.Initialized environment parameter is not set.  Run Enable-SRxOMS."
			Write-SRx ERROR $errMsg
            exit
		}
        $TimeStampField = "Timestamp"
 
        $DataComponentArray=@()
        $DataComponentArray_SSATimerJobs=@()
	}
	PROCESS
	{
        if(-not (Confirm-SRxLicenseAgreement))
        {
            Write-SRx INFO "Aborting populate export to OMS. License not accepted." -ForegroundColor Red
            return
        }
		foreach($d in $data) {
			if($d.Dashboard -ne $true) {
                Write-SRx VERBOSE "Not writing $($d.Name) to Dashboard."
                continue
            }

            $SRxTestName        = $d.Name
            $SRxTestName        = $SRxTestName -replace "Test-",""
            $SRxTestAlert       = [Bool]$d.Alert
 
            if($d.Category.Count -gt 1){
                $SRxTestCategory   = $d.Category -join "|"
            }else{
                $SRxTestCategory   = $d.Category
            }
 
            $SRxTestHeadline = $d.Headline
            $SRxTestTimestamp = $d.Timestamp
            $SRxTestFarmId = [GUID]$d.FarmId
            $SRxTestRunId = $d.RunId
            $SRxTestSource = $d.Source
 
            $SRxTestLevel = $d.Level
            if($d.Level -eq "Normal"){
                $SRxTestLevelCode = 2
            } elseIf($d.Level -eq "Warning"){
                $SRxTestLevelCode = 11
            } elseIf($d.Level -eq "Error"){
                $SRxTestLevelCode = 111
            } elseIf($d.Level -eq "INFO"){
                $SRxTestLevelCode = 1
            } else {
                $SRxTestLevelCode = 400
            }
 
            $SRxTestResult = [Bool]$d.Result 
            $SRxTestData = $d.Data | ConvertTo-Json -Compress -Depth 12
 
            $DataComponentArray += @{"Name"=$SRxTestName.ToString();"Alert"=$SRxTestAlert;"Category"=$SRxTestCategory.ToString();"Headline"=$SRxTestHeadline.ToString();"Timestamp"=$SRxTestTimestamp;"FarmId"=$SRxTestFarmId;"RunId"=$SRxTestRunId;"Source"=$SRxTestSource.ToString();"Level"=$SRxTestLevel.ToString();"Level Code"=[Double]$SRxTestLevelCode;"Result"=$SRxTestResult;"DataPayload"=$SRxTestData}
 
            if($d.Name -like "*SSATimerJobs"){
                $SRxTestData1 = $d.Data | ConvertTo-Json
                $SSATimerJobs = $SRxTestData1 | ConvertFrom-Json
         
                $svcJobs = $SSATimerJobs.svcJobs
                $ssaJobs = $SSATimerJobs.ssaJobs
              
                ForEach($svcJob in $svcJobs)
                {
                        If($svcJob.lastSuccess -eq "Not available")
                        {
                            $nullDate = Get-Date -Year 1900 -Month 1 -Day 1 -Hour 0 -Minute 0 -second 0
                            $lastSuccess = Get-Date $nullDate -format "yyyy-MM-ddThh:mm:ss.fffZ"
                        }
                        else
                        {
                            $lastSuccess = Get-Date $svcJob.lastSuccess -format "yyyy-MM-ddThh:mm:ss.fffZ"
                        }

                        If($svcJob.lastFail -eq "Not available")
                        {
                            $nullDate = Get-Date -Year 1900 -Month 1 -Day 1 -Hour 0 -Minute 0 -second 0
                            $lastFail = Get-Date $nullDate -format "yyyy-MM-ddThh:mm:ss.fffZ"
                        }
                        else
                        {
                            $lastFail = Get-Date $svcJob.lastFail -format "yyyy-MM-ddThh:mm:ss.fffZ"
                        }
                        $jobstatus = [String]$svcJob.status
                        $jobName = $svcJob.name
                        if($svcJob.runTimeMins -eq "Unknown"){
                            $runTimeMins = -1              
                        } else {
                            $runTimeMins =$svcJob.runTimeMins              
                        }
                        $nextrun = $svcJob.nextRun
                        $DataComponentArray_SSATimerJobs += @{"SSATimerJobName"="svcJob";"JobName"=$jobName.ToString();"runTimeMins"=[Double]$runTimeMins;"lastFailDT"=$lastFail;"nextRun"=$nextrun.ToString();"status"=$jobstatus;"lastSuccessDT"=$lastSuccess}
                }
              
                ForEach($ssaJob in $ssaJobs)
                {
                        $lastSuccess = Get-Date $ssaJob.lastSuccess -format "yyyy-MM-ddThh:mm:ss.fffZ"
                        If($ssaJobs.lastFail -eq "Not available")
                        {
                            $nullDate = Get-Date -Year 1900 -Month 1 -Day 1 -Hour 0 -Minute 0 -second 0
                            $lastFail = Get-Date $nullDate -format "yyyy-MM-ddThh:mm:ss.fffZ"
                        }
                        else
                        {
                            $lastFail = Get-Date $ssaJobs.lastFail -format "yyyy-MM-ddThh:mm:ss.fffZ"
                        }
                        $jobstatus = [String]$ssaJob.status
                        $jobName = $ssaJob.name
                        $runTimeMins =$ssaJob.runTimeMins
                        $nextrun = $ssaJob.nextRun
                        $DataComponentArray_SSATimerJobs += @{"SSATimerJobName"="ssaJob";"JobName"=$jobName.ToString();"runTimeMins"=[Double]$runTimeMins;"lastFailDT"=$lastFail;"nextRun"=$nextrun.ToString();"status"=$jobstatus;"lastSuccessDT"=$lastSuccess}
                }                         
              
                $jsonPayload_SSATimerJobs = $DataComponentArray_SSATimerJobs | ConvertTo-Json
            }
        }
 
        $jsonPayload = $DataComponentArray | ConvertTo-Json -Compress

		if($PassThru) { $d }
	}
	END
	{
        $customerId = $global:SRxEnv.OMS.CustomerId
        $sharedKey = $global:SRxEnv.OMS.SharedKey
        if(-not [string]::IsNullOrEmpty($jsonPayload)){
            $LogType = "SRxAssessmentResult"
            $response = Post-OMSData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonPayload)) -logType $logType
            if($response -eq 200){
                Write-SRx Info "Successfully uploaded test results to OMS" -ForegroundColor Green 
            } else {
                Write-SRx Error "Failed uploading results to OMS. Post-OMSData returned code $response."
            }
        }
        if(-not [string]::IsNullOrEmpty($jsonPayload_SSATimerJobs)){
            $LogType_SSATimerJobs = "SSATimerJobs"
            $response = Post-OMSData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($jsonPayload_SSATimerJobs)) -logType $LogType_SSATimerJobs
            if($response -eq 200){
                Write-SRx Info "Successfully uploaded SSATimerJobs test results to OMS" -ForegroundColor Green 
            } else {
                Write-SRx Error "Failed uploading results to OMS. Post-OMSData returned code $response."
            }
        }
	}
}
Export-ModuleMember Export-SRxToOMS 

function Enable-SRxOMS
{ 
    if(-not $global:SRxEnv.OMS) {
        $global:SRxEnv.PersistCustomProperty("OMS", $(New-Object PSObject))
    }
	if($global:SRxEnv.OMS.Initialized){
        Write-SRx WARNING "OMS has already been configured."

		$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Change OMS settings."
		$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Do not change OMS settings."
		$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)

        Write-Host "Do you want to modify OMS settings?" -BackgroundColor DarkCyan -ForegroundColor White
        Write-Host "Customer Id: $($global:SRxEnv.OMS.CustomerId)" -BackgroundColor DarkCyan -ForegroundColor White
        Write-Host "Shared Key: $($global:SRxEnv.OMS.SharedKey)" -BackgroundColor DarkCyan -ForegroundColor White
		$title = "" 
		$message = "Do you want modify OMS settings?"
		$result = $host.ui.PromptForChoice($title, $message, $options, 1)
		switch ($result) 
		{
			0 { Write-Host "Yes";}
			1 { Write-Host "No"; return }
		}
    }

    $choiceConfirmed = $false
    while(-not $choiceConfirmed){
	    Write-Host "Enter the OMS Workspace Id." -BackgroundColor DarkCyan -ForegroundColor White
	    Write-Host "Report data from this farm will be added to the OMS Workspace." -BackgroundColor DarkCyan -ForegroundColor White
        if($($global:SRxEnv.OMS.CustomerId)){
            $customerId = Read-Host ">> Enter the Workspace Id [$($global:SRxEnv.OMS.CustomerId)]"
	        if([string]::IsNullOrEmpty($customerId))
	        {
		        $customerId = $global:SRxEnv.OMS.CustomerId
	        }
        } else {
    	    $customerId = Read-Host ">> Enter the Workspace Id"
        }
        $customerId = $customerId.Trim()

	    $yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Accept the name."
	    $no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Re-enter the name."
	    $quit = New-Object System.Management.Automation.Host.ChoiceDescription "&Quit","Exit."
	    $options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no, $quit)
	    $title = "" 
	    $message = "You have entered '$customerId'. Is this correct?"
	    $result = $host.ui.PromptForChoice($title, $message, $options, 0)
	    switch ($result) 
	    {
		    0 { Write-Host "Yes"; $choiceConfirmed = $true}
		    1 { Write-Host "No"; $customerId = "" }
		    2 { Write-Host "Quit"; return}
	    }
    }
    $choiceConfirmed = $false
    while(-not $choiceConfirmed){
	    Write-Host "Enter the OMS Shared Key." -BackgroundColor DarkCyan -ForegroundColor White
	    Write-Host "Report data from this farm will be added to the OMS Workspace." -BackgroundColor DarkCyan -ForegroundColor White
        if($($global:SRxEnv.OMS.SharedKey)){
            $sharedKey = Read-Host ">> Enter the Shared Key [$($global:SRxEnv.OMS.SharedKey)]"
	        if([string]::IsNullOrEmpty($sharedKey))
	        {
		        $sharedKey = $global:SRxEnv.OMS.SharedKey
	        }
        } else {
    	    $sharedKey = Read-Host ">> Enter the Shared Key"
        }
        $sharedKey = $sharedKey.Trim()

	    $yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Accept the name."
	    $no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Re-enter the name."
	    $quit = New-Object System.Management.Automation.Host.ChoiceDescription "&Quit","Exit."
	    $options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no, $quit)
	    $title = "" 
	    $message = "You have entered '$sharedKey'. Is this correct?"
	    $result = $host.ui.PromptForChoice($title, $message, $options, 0)
	    switch ($result) 
	    {
		    0 { Write-Host "Yes"; $choiceConfirmed = $true}
		    1 { Write-Host "No"; $sharedKey = "" }
		    2 { Write-Host "Quit"; return}
	    }
    }
    if($choiceConfirmed)
    {
        # update config for OMS
        $global:SRxEnv.PersistCustomProperty("OMS.Initialized", $true)
        $global:SRxEnv.PersistCustomProperty("OMS.CustomerId", $customerId)
	    $global:SRxEnv.PersistCustomProperty("OMS.SharedKey", $sharedKey)
    }
}
Export-ModuleMember Enable-SRxOMS 

Function Build-Signature ($customerId, $sharedKey, $date, $contentLength, $method, $contentType, $resource)
{
    $xHeaders = "x-ms-date:" + $date
    $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource
 
    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($sharedKey)
 
    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $customerId,$encodedHash
    return $authorization
}
 
Function Post-OMSData($customerId, $sharedKey, $body, $logType) 
{
    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $body.Length
     $signature = Build-Signature `
        -customerId $customerId `
        -sharedKey $sharedKey `
        -date $rfc1123date `
        -contentLength $contentLength `
        -fileName $fileName `
        -method $method `
        -contentType $contentType `
        -resource $resource
    $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"
 
    $headers = @{
        "Authorization" = $signature;
        "Log-Type" = $logType;
        "x-ms-date" = $rfc1123date;
        "time-generated-field" = $TimeStampField;
    }

    $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
    return $response.StatusCode
} 



 

# SIG # Begin signature block
# MIIkpgYJKoZIhvcNAQcCoIIklzCCJJMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAva6prGgj+Z+r/
# L7KUH6DbHT4IH5nULELorkZgRIq1AaCCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWezCCFncCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCCAWkwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJht4dbe
# dOV0h6s9qFPqDMD8VVz6LRhg6WwljVLstkK1MIH8BgorBgEEAYI3AgEMMYHtMIHq
# oFaAVABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAGEAcgBjAGgAIABIAGUAYQBs
# AHQAaAAgAFIAZQBwAG8AcgB0AHMAIABEAGEAcwBoAGIAbwBhAHIAZKGBj4CBjGh0
# dHBzOi8vYmxvZ3MubXNkbi5taWNyb3NvZnQuY29tL3NoYXJlcG9pbnRfc3RyYXRl
# Z2VyeS8yMDE2LzAyLzAxL2Fubm91bmNpbmctdGhlLXNlYXJjaC1oZWFsdGgtcmVw
# b3J0cy1zcngtZm9yLXNoYXJlcG9pbnQtc2VhcmNoLWRpYWdub3N0aWNzMA0GCSqG
# SIb3DQEBAQUABIIBAA1DuL0cxUI8xoJYm6ZUsU2QxItuILV0bz9JxbCbypcDeDe8
# 6yxeykcfBgqFquVhOERYhyeSEXhi/onX6PNtNugEBscRT0Voyr/jbyQQBCuUDPR6
# FJJBIhW44Q+/bs0NowkCP7NnXKo/n5G+nwrVYGxouo829ic33giCHyW8H5TNjX8C
# czn99c+chkzmhD+6BEE5visNI6tlgg3RGZnaTMQJiUEMpqlWL9vXr8mAqEcLY3cG
# 15O3euEaz8Ftnp+DO4bgNqjDxPVkDv7qsvhk6SJTzNiKGiNYw9+xXsnnbM2bT+BT
# EOgxiWirts5VsaRO+tMHXye/twSMNt509bX9rOihghNJMIITRQYKKwYBBAGCNwMD
# ATGCEzUwghMxBgkqhkiG9w0BBwKgghMiMIITHgIBAzEPMA0GCWCGSAFlAwQCAQUA
# MIIBPQYLKoZIhvcNAQkQAQSgggEsBIIBKDCCASQCAQEGCisGAQQBhFkKAwEwMTAN
# BglghkgBZQMEAgEFAAQgkd7R4jUa4ayms+JLtBK9s7ZRV8D1dlETfeATjONPDfgC
# BltoddhFaxgTMjAxODA4MTcyMjA4MjAuNjkyWjAHAgEBgAIB9KCBuaSBtjCBszEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9Q
# UjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNOOkIxQjctRjY3Ri1GRUMyMSUwIwYD
# VQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIOzDCCBNowggPCoAMC
# AQICEzMAAACxcRN533X2NcgAAAAAALEwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTYwOTA3MTc1NjU3WhcNMTgwOTA3MTc1
# NjU3WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsG
# A1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNOOkIxQjctRjY3Ri1G
# RUMyMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqqQklG1Y1lu8ob0P7deumuRn4JvR
# i2GErmK94vgbnWPmd0j/9arA7539HD1dpG1uhYbmnAxc+qsuvMM0fpEvttTK4lZS
# U7ss5rJfWmbFn/J8kSGI8K9iBaB6hQkJuIX4si9ppNr9R3oZI3HbJ/yRkKUPk4ho
# zpY6CkehRc0/Zfu6tQiyqI7mClXYZTXjw+rLsh3/gdBvYDd38zFBllaf+3uimKQg
# UTXGjbKfqZZk3tEU3ibWVPUxAmmxlG3sWTlXmU31fCw/6TVzGg251lq+Q46OjbeH
# 9vB2TOcqEso4Nai3J1CdMAYUdlelVVtgQdIx/c+5Hvrw0Y6W7uGBAWnW5wIDAQAB
# o4IBGzCCARcwHQYDVR0OBBYEFE5XPfeLLhRLV7L8Il7Tz7cnRBA7MB8GA1UdIwQY
# MBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6
# Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBD
# QV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# DQYJKoZIhvcNAQELBQADggEBAHPujfu0W8PBTpjfYaPrAKIBLKcljT4+YnWbbgGv
# mXU8OvIUDBkkv8gNGGHRO5DSySaCARIzgn2yIheAqh6GwM2yKrfb4eVCYPe1CTlC
# seS5TOv+Tn/95mXj+NxTqvuNmrhgCVr0CQ7b3xoKcwDcQbg7TmerDgbIv2k7cEqb
# YbU/B3MtSX8Zjjf0ZngdKoX0JYkAEDbZchOrRiUtDJItegPKZPf6CjeHYjrmKwvT
# OVCzv3lW0uyh1yb/ODeRH+VqENSHCboFiEiq9KpKMOpek1VvQhmI2KbTlRvK869g
# j1NwuUHH8c3WXu4A0X1+CBmU8t0gvd/fFlQvw04veKWh984wggZxMIIEWaADAgEC
# AgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0
# aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEy
# MTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCC
# hfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRU
# QwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FU
# sc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBX
# day9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4
# HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCC
# AeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2ha
# hW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNV
# HRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYG
# A1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3Js
# L3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcB
# AQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kv
# Y2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUw
# gZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0
# HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0
# AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1
# Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRg
# Eop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X
# 9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbl
# jjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQ
# eKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ou
# OVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+9
# 8eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUB
# HoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ay
# p0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXj
# ad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb
# 01+P3nSISRKhggN1MIICXQIBATCB46GBuaSBtjCBszELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNp
# cGhlciBEU0UgRVNOOkIxQjctRjY3Ri1GRUMyMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBTZXJ2aWNloiUKAQEwCQYFKw4DAhoFAAMVADq635MoZeR60+ej
# 9uKnRG5YqlPSoIHCMIG/pIG8MIG5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMScwJQYDVQQLEx5uQ2lwaGVyIE5UUyBF
# U046NTdGNi1DMUUwLTU1NEMxKzApBgNVBAMTIk1pY3Jvc29mdCBUaW1lIFNvdXJj
# ZSBNYXN0ZXIgQ2xvY2swDQYJKoZIhvcNAQEFBQACBQDfIXzpMCIYDzIwMTgwODE4
# MDA1NzEzWhgPMjAxODA4MTkwMDU3MTNaMHMwOQYKKwYBBAGEWQoEATErMCkwCgIF
# AN8hfOkCAQAwBgIBAAIBUTAHAgEAAgIYJzAKAgUA3yLOaQIBADA2BgorBgEEAYRZ
# CgQCMSgwJjAMBgorBgEEAYRZCgMBoAowCAIBAAIDFuNgoQowCAIBAAIDB6EgMA0G
# CSqGSIb3DQEBBQUAA4IBAQB+721NNQMD0v6CptaDGpC35/kaohxPw3hKQwtjxoYz
# Apri4mxGADQ7oljSv0SJFYAM/QSGTNGbX6PEFwjYXhctfDiHXHTBFcNCez155e4F
# LHLtS9/OKnsg886UW1D3yYKNV0FKhBWV6lyY4BbYtQdIitJRk/qu6usp1qkW5i37
# sakXi26TohlHdCzdJRBomHt99n4lkl1d/tsC+NWuaPhO+b+8Ua9EO2tdAoxCr8S+
# SUIA3jMWPxbXa0Cl9x6WjlG6sjOx/h+gx5OvkRXj9ykxPB7z5F1xsTYfOQfmcHH2
# /gQLbzwDbiyPjGmSzTK88+rH4AMs0/Uu/QGeJ1ynDYWcMYIC9TCCAvECAQEwgZMw
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAACxcRN533X2NcgAAAAA
# ALEwDQYJYIZIAWUDBAIBBQCgggEyMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAvBgkqhkiG9w0BCQQxIgQg3YfKOmk7EWWBMf8pVAdNgvatV5T9NeYHBQD2H24W
# u74wgeIGCyqGSIb3DQEJEAIMMYHSMIHPMIHMMIGxBBQ6ut+TKGXketPno/bip0Ru
# WKpT0jCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA
# sXETed919jXIAAAAAACxMBYEFGdVrY7osmZQyr7jTvekYOepPRW2MA0GCSqGSIb3
# DQEBCwUABIIBABTJzsVYreABYODpgAvVtcW+nq36yMVZ8T2K5KW4A202vfvJn/3F
# ryYVYzYQxU7R1cFXLzXVYhS6cbm/fVi8flpFpo9g7+x1DlOgM/0FWRF+AVvxAric
# i0PgsXNo5jky7jWDzl2f0gD2TGmUfbi9XZD5ryb8rM5Hg94bvVFw+vchSKkFDR69
# Qpx3s53hUrEAmGV40Zw96SIpS6qPPJC0DymnJIyBqpyGskF8cdQbXnwsYD71ztLh
# JBC8n3Gje7mDr2Nd0JD7mFAwA1/QlOfN3ho9i5MFLePIj90ZEn2wovpoClQMQZcT
# DLMJ9UAJqeM0BiHDnNoAioJeTEjITBf3UGQ=
# SIG # End signature block
