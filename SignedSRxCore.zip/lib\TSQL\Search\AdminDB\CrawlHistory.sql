SELECT **TOP**
FROM [**SEARCHADMIN**].[dbo].[MSSCrawlHistory] WITH (nolock)
**WHERE**
ORDER BY MSSCrawlHistory.CrawlId DESC

